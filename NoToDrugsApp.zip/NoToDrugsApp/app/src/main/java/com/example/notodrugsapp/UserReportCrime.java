package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserReportCrime extends AppCompatActivity implements View.OnClickListener {
    String uid,cid,cname,oid,oname;
    EditText txtsubject,txtdescription;
    Spinner spcategory,spexciseoffice;
    Button btnsubmit,btnupload;
    List<String> arrlistcategoryid,arrlistcategoryname,arrlistexciseofficeid,arrlistexciseofficename;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_report_crime);
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        uid=sp.getString("userid","");
        arrlistcategoryid=new ArrayList<String>();
        arrlistcategoryname=new ArrayList<String>();
        arrlistexciseofficeid=new ArrayList<String>();
        arrlistexciseofficename=new ArrayList<String>();

        txtsubject=findViewById(R.id.txtsubject);
        txtdescription=findViewById(R.id.txtdescription);
        spcategory=findViewById(R.id.spcategory);
        spexciseoffice=findViewById(R.id.spexciseoffice);
        btnsubmit=findViewById(R.id.btnsubmit);
        btnupload=findViewById(R.id.btnupload);

        btnupload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),UserUploadCrimeProof.class);
                startActivity(intent);
            }
        });

        btnsubmit.setOnClickListener(this);
        GetCategory getCategory=new GetCategory();
        getCategory.execute();
        //Toast.makeText(this,uid, Toast.LENGTH_SHORT).show();
        GetExciseOffices2 getExciseOffices2=new GetExciseOffices2();
        getExciseOffices2.execute(uid);

        spcategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spexciseoffice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        String subject=txtsubject.getText().toString();
        String description=txtdescription.getText().toString();
        String categoryid=arrlistcategoryid.get(spcategory.getSelectedItemPosition());
        String exciseofficeid=arrlistexciseofficeid.get(spexciseoffice.getSelectedItemPosition());
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        String filename=sp.getString("filename","");
        String userid=sp.getString("userid","");
        CrimeReport crimeReport=new CrimeReport();
        crimeReport.execute(subject,description,categoryid,exciseofficeid,userid,filename);
    }

    private class CrimeReport extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("CrimeReport");
            wb.addProperty("subject",strings[0]);
            wb.addProperty("description",strings[1]);
            wb.addProperty("categoryid",strings[2]);
            wb.addProperty("exciseofficeid",strings[3]);
            wb.addProperty("userid",strings[4]);
            wb.addProperty("filename",strings[5]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(UserReportCrime.this,s, Toast.LENGTH_SHORT).show();
        }
    }


    private class GetCategory extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetCategory");
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                //Toast.makeText(UserReportCrime.this,ja.toString(), Toast.LENGTH_SHORT).show();
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    cid=jo.getString("categoryid");
                    cname=jo.getString("categoryname");
                    arrlistcategoryid.add(cid);
                    arrlistcategoryname.add(cname);
                }
                ArrayAdapter<String> adapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_spinner_dropdown_item,arrlistcategoryname);
                spcategory.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    private class GetExciseOffices2 extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetExciseOffices2");
            wb.addProperty("uid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    oid=jo.getString("officeid");
                    oname=jo.getString("officename");
                    arrlistexciseofficeid.add(oid);
                    arrlistexciseofficename.add(oname);
                }
                ArrayAdapter<String> adapter=new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_spinner_dropdown_item,arrlistexciseofficename);
                spexciseoffice.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}
