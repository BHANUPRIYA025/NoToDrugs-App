package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class UserReportedCrimeItemDetails extends AppCompatActivity {

    TextView txtsubject,txtcrimecategory,txtoffice,txtdescription,txtreporteddate,txtreplay;
    ImageButton imgbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_reported_crime_item_details);

        Intent i=getIntent();
        String crimeid=i.getStringExtra("crimeid");
        //Toast.makeText(this,crimeid, Toast.LENGTH_SHORT).show();

        txtsubject=findViewById(R.id.txtsubject);
        txtcrimecategory=findViewById(R.id.txtcrimecategory);
        txtdescription=findViewById(R.id.txtdescription);
        txtoffice=findViewById(R.id.txtoffice);
        txtreporteddate=findViewById(R.id.txtreporteddate);
        txtreplay=findViewById(R.id.txtreplay);
        imgbtn=findViewById(R.id.pro_img);

        GetReportedCrimeItemDetails getReportedCrimeItemDetails=new GetReportedCrimeItemDetails();
        getReportedCrimeItemDetails.execute(crimeid);

    }

    private class GetReportedCrimeItemDetails extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetReportedCrimeItemDetails");
            wb.addProperty("crimeid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                JSONObject jo=ja.getJSONObject(0);
                String subject=jo.getString("subject");
                String crimecategory=jo.getString("crimecategory");
                String office=jo.getString("office");
                String description=jo.getString("description");
                String reporteddate=jo.getString("reporteddate");
                String replay=jo.getString("replay");
                String photo=jo.getString("photo");

                txtsubject.setText(subject);
                txtcrimecategory.setText(crimecategory);
                txtoffice.setText(office);
                txtdescription.setText(description);
                txtreporteddate.setText(reporteddate);
                txtreplay.setText(replay);
                String urlip= getApplicationContext().getResources().getString(R.string.ip);
                Picasso.with(getApplicationContext()).load("http://"+urlip+"/MainProject/User/CrimeProof/"+photo+"").fit().into(imgbtn);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}
