package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserJoinedAAGroup extends AppCompatActivity {
    //List<String> arrlistGroup;
    String userid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_joined_aagroup);
        //arrlistGroup=new ArrayList<String>();
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        userid=sp.getString("userid","");
        GetJoinedAAGroup getJoinedAAGroup=new GetJoinedAAGroup();
        getJoinedAAGroup.execute(userid);
        //Toast.makeText(UserJoinedAAGroup.this,userid, Toast.LENGTH_SHORT).show();
    }

    private class GetJoinedAAGroup extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetJoinedAAGroup");
            wb.addProperty("userid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                UserJoinedAAGroupItems[] myListData=new UserJoinedAAGroupItems[ja.length()];
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    String groupid=jo.getString("groupid");
                    String groupname=jo.getString("groupname");
                    String district=jo.getString("district");
                    String place=jo.getString("place");
                    String contact=jo.getString("contact");
                    String email=jo.getString("email");
                    String address=jo.getString("address");
                    myListData[i]=new UserJoinedAAGroupItems(groupid,groupname,district,place);
                }

                Toast.makeText(UserJoinedAAGroup.this,userid, Toast.LENGTH_SHORT).show();
                RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycle_joined_aagroup);
                UserJoinedAAGroupAdapter adapter = new UserJoinedAAGroupAdapter(myListData);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(UserJoinedAAGroup.this));
                recyclerView.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    }
}
