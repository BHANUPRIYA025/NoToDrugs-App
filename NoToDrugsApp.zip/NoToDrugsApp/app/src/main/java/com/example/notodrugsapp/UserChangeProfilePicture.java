package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;

import cz.msebera.android.httpclient.Header;


public class UserChangeProfilePicture extends AppCompatActivity implements View.OnClickListener {

    ImageButton imgbtn;
    Button btnselect,btnchange;
    String userid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_change_profile_picture);

        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        userid=sp.getString("userid","");

        btnselect=findViewById(R.id.btnselect);
        btnchange=findViewById(R.id.btnchange);
        imgbtn=findViewById(R.id.pro_img);

        btnselect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),UserChangeProfilePictureUpload.class);
                startActivity(intent);
            }
        });

        btnchange.setOnClickListener(this);

        GetUserPicture getUserPicture=new GetUserPicture();
        getUserPicture.execute(userid);


    }

    @Override
    public void onClick(View v) {
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        String filename=sp.getString("filename","");
        ChangeProfilePicture changeProfilePicture=new ChangeProfilePicture();
        changeProfilePicture.execute(userid,filename);
    }

    private class GetUserPicture extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb = new WebServiceCaller();
            wb.setSoapObject("GetUserPicture");
            wb.addProperty("userid", strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja = new JSONArray(s);
                JSONObject jo = ja.getJSONObject(0);
                String photo=jo.getString("photo");
                //Toast.makeText(UserChangeProfilePicture.this,photo, Toast.LENGTH_SHORT).show();
                String urlip= getApplicationContext().getResources().getString(R.string.ip);
                Picasso.with(getApplicationContext()).load("http://"+urlip+"/MainProject/User/Photo/"+photo+"").fit().into(imgbtn);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class ChangeProfilePicture extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("ChangeProfilePicture");
            wb.addProperty("userid",strings[0]);
            wb.addProperty("filename",strings[1]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(UserChangeProfilePicture.this,s, Toast.LENGTH_SHORT).show();
            GetUserPicture getUserPicture=new GetUserPicture();
            getUserPicture.execute(userid);
        }
    }
}
