package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserRegistration extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    EditText txtname,txtcontact,txtemail,txtusername,txtpassword,txtaddress;
    RadioButton rdbmale,rdbfemale;
    Button btnregister;
    Spinner spdistrict,spplace;
    String name,contact,email,username,password,address,gender,districtid,placeid;
    List<String> arrlistDistrictName,arrlistDistrictId,arrlistPlaceId,arrlistPlaceName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        arrlistDistrictName=new ArrayList<String>();
        arrlistDistrictId=new ArrayList<String>();
        setContentView(R.layout.activity_user_registration);
        txtname=findViewById(R.id.txtname);
        txtcontact=findViewById(R.id.txtcontact);
        txtemail=findViewById(R.id.txtemail);
        txtusername=findViewById(R.id.txtusername);
        txtpassword=findViewById(R.id.txtpassword);
        txtaddress=findViewById(R.id.txtaddress);
        rdbmale=findViewById(R.id.rdbmale);
        rdbfemale=findViewById(R.id.rdbfemale);
        btnregister=findViewById(R.id.btnregister);
        spdistrict=(Spinner)findViewById(R.id.spdistrict);
        spplace=(Spinner)findViewById(R.id.spplace);

        btnregister.setOnClickListener(this);
        spdistrict.setOnItemSelectedListener(this);


        GetDistrict getDistrict=new GetDistrict();
        getDistrict.execute();

        spplace.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String did=arrlistDistrictId.get(position);
        ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
        GetPlace getPlace=new GetPlace();
        getPlace.execute(did);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private class GetPlace extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetPlace");
            wb.addProperty("districtid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
            JSONArray ja=new JSONArray(s);
            arrlistPlaceName=new ArrayList<String>();
            arrlistPlaceId=new ArrayList<String>();
            //Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    String pid=jo.getString("placeid");
                    String pname=jo.getString("placename");
                    //Log.d("id",pid);
                    arrlistPlaceId.add(pid);
                    arrlistPlaceName.add(pname);

                }
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, arrlistPlaceName);
                spplace.setAdapter(adapter);

            } catch (JSONException e) {
               e.printStackTrace();
            }

        }
    }

    private class GetDistrict extends AsyncTask<String,String,String> {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb = new WebServiceCaller();
            wb.setSoapObject("GetDistrict");
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            //Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
            try {
                JSONArray ja = new JSONArray(s);
                //Toast.makeText(getApplicationContext(),ja.toString(),Toast.LENGTH_LONG).show();
                for (int i = 0; i < ja.length(); i++) {
                    JSONObject jsonObject1 = ja.getJSONObject(i);
                    String dname = jsonObject1.getString("districtname");
                    String did = jsonObject1.getString("districtid");
                    arrlistDistrictId.add(did);
                    arrlistDistrictName.add(dname);
                }
                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, arrlistDistrictName);
                //adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
                spdistrict.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class CreateUser extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("CreateUser");
            wb.addProperty("name",strings[0]);
            wb.addProperty("gender",strings[1]);
            wb.addProperty("contact",strings[2]);
            wb.addProperty("email",strings[3]);
            wb.addProperty("address",strings[4]);
            wb.addProperty("districtid",strings[5]);
            wb.addProperty("placeid",strings[6]);
            wb.addProperty("username",strings[7]);
            wb.addProperty("password",strings[8]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(UserRegistration.this,s, Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onClick(View v) {
        if(v==btnregister)
        {
            name=txtname.getText().toString();
            contact=txtcontact.getText().toString();
            email=txtemail.getText().toString();
            username=txtusername.getText().toString();
            password=txtpassword.getText().toString();
            address=txtaddress.getText().toString();
            if(rdbmale.isChecked())
            {
                gender="male";
            }
            else if (rdbfemale.isChecked())
            {
                gender="female";
            }
            districtid=arrlistDistrictId.get(spdistrict.getSelectedItemPosition());
            placeid=arrlistPlaceId.get(spplace.getSelectedItemPosition());
            CreateUser createUser=new CreateUser();
            createUser.execute(name,gender,contact,email,address,districtid,placeid,username,password);
        }

    }
}
