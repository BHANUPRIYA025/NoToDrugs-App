package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AAGroupRegistration extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {
    EditText txtname,txtcontact,txtemail,txtaddress,txtusername,txtpassword;
    Spinner spdistrict,spplace;
    Button btnregister;
    String name,contact,email,address,username,password,districtid,placeid;
    List<String> arrlistDistrictId,arrlistDistrictName,arrlistPlaceId,arrlistPlaceName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aagroup_registration);
        arrlistDistrictId=new ArrayList<String>();
        arrlistDistrictName=new ArrayList<String>();
        txtname=findViewById(R.id.txtname);
        txtcontact=findViewById(R.id.txtcontact);
        txtemail=findViewById(R.id.txtemail);
        txtaddress=findViewById(R.id.txtaddress);
        txtusername=findViewById(R.id.txtusername);
        txtpassword=findViewById(R.id.txtpassword);
        spdistrict=findViewById(R.id.spdistrict);
        spplace=findViewById(R.id.spplace);
        btnregister=findViewById(R.id.btnregister);
        GetDistrict getDistrict=new GetDistrict();
        getDistrict.execute();
        spdistrict.setOnItemSelectedListener(this);
        btnregister.setOnClickListener(this);

        spplace.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String did=arrlistDistrictId.get(position);
        ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
        GetPlace getPlace=new GetPlace();
        getPlace.execute(did);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {
        if(v==btnregister)
        {
            name=txtname.getText().toString();
            contact=txtname.getText().toString();
            email=txtemail.getText().toString();
            address=txtaddress.getText().toString();
            username=txtusername.getText().toString();
            password=txtpassword.getText().toString();
            districtid=arrlistDistrictId.get(spdistrict.getSelectedItemPosition());
            placeid=arrlistPlaceId.get(spplace.getSelectedItemPosition());
            CreateAAGroup createAAGroup=new CreateAAGroup();
            createAAGroup.execute(name,contact,email,address,username,password,districtid,placeid);

        }
    }

    private class CreateAAGroup extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("CreateAAGroup");
            wb.addProperty("name",strings[0]);
            wb.addProperty("contact",strings[1]);
            wb.addProperty("email",strings[2]);
            wb.addProperty("address",strings[3]);
            wb.addProperty("username",strings[4]);
            wb.addProperty("password",strings[5]);
            wb.addProperty("districtid",strings[6]);
            wb.addProperty("placeid",strings[7]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(AAGroupRegistration.this,s, Toast.LENGTH_SHORT).show();
        }
    }

    private class GetPlace extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetPlace");
            wb.addProperty("districtid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                arrlistPlaceId=new ArrayList<String>();
                arrlistPlaceName=new ArrayList<String>();
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    String pid=jo.getString("placeid");
                    String pname=jo.getString("placename");
                    arrlistPlaceId.add(pid);
                    arrlistPlaceName.add(pname);
                }
                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, arrlistPlaceName);
                spplace.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    private class GetDistrict extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetDistrict");
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    String did=jo.getString("districtid");
                    String dname=jo.getString("districtname");
                    arrlistDistrictId.add(did);
                    arrlistDistrictName.add(dname);
                }
                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, arrlistDistrictName);
                spdistrict.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}

