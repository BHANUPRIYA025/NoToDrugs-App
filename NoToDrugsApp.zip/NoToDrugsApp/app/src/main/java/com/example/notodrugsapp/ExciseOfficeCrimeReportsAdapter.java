package com.example.notodrugsapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class ExciseOfficeCrimeReportsAdapter extends RecyclerView.Adapter<ExciseOfficeCrimeReportsAdapter.ViewHolder> {

    private ExciseOfficeCrimeReportsItems[] listdata;

    public ExciseOfficeCrimeReportsAdapter(ExciseOfficeCrimeReportsItems[] listdata) {
        this.listdata = listdata;
    }

    public ExciseOfficeCrimeReportsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.activity_excise_office_crime_reports_items, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    public void onBindViewHolder(@NonNull ExciseOfficeCrimeReportsAdapter.ViewHolder holder, final int position) {

        final ExciseOfficeCrimeReportsItems myListData = listdata[position];
        holder.crimename.setText(listdata[position].getCrimename());
        holder.user.setText(listdata[position].getUser());
        holder.reportdate.setText(listdata[position].getReportdate());
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), ExciseOfficeCrimeReportsItemDetails.class);
                intent.putExtra("crimeid", listdata[position].getCrimeid());
                view.getContext().startActivity(intent);
                //Toast.makeText(view.getContext(), "click on item: " + myListData.getCrimeid(), Toast.LENGTH_LONG).show();
            }
        });

    }

    public int getItemCount() {
        return listdata.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView crimename,user,reportdate;
        public RelativeLayout relativeLayout;

        public ViewHolder(View itemView) {
            super(itemView);
            this.crimename = (TextView) itemView.findViewById(R.id.txtcrimename);
            this.user = (TextView) itemView.findViewById(R.id.txtuser);
            this.reportdate = (TextView) itemView.findViewById(R.id.txtreportdate);
            relativeLayout = (RelativeLayout) itemView.findViewById(R.id.exciseofficecrimereportsrelativelayout);
        }
    }
}
