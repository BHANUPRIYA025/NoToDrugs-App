package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AAGroupApproveMemberItemDetails extends AppCompatActivity implements View.OnClickListener {

    TextView txtmember,txtplace,txtdistrict,txtcontact,txtemail,txtaddress;
    Button btnapprove,btnreject;
    ImageButton imgbtn;
    String memberid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aagroup_approve_member_item_details);

        Intent i=getIntent();
        memberid=i.getStringExtra("memberid");

        txtmember=findViewById(R.id.txtmember);
        txtplace=findViewById(R.id.txtplace);
        txtdistrict=findViewById(R.id.txtdistrict);
        txtcontact=findViewById(R.id.txtcontact);
        txtemail=findViewById(R.id.txtemail);
        txtaddress=findViewById(R.id.txtaddress);
        btnapprove=findViewById(R.id.btnapprove);
        btnreject=findViewById(R.id.btnreject);
        imgbtn=findViewById(R.id.pro_img);

        GetApproveMemberItemDetails getApproveMemberItemDetails=new GetApproveMemberItemDetails();
        getApproveMemberItemDetails.execute(memberid);

        btnapprove.setOnClickListener(this);
        btnreject.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {

        String mid=memberid;
        if(v==btnapprove)
        {
            AcceptMember acceptMember=new AcceptMember();
            acceptMember.execute(mid);
        }
        if(v==btnreject)
        {
            RejectMember rejectMember=new RejectMember();
            rejectMember.execute(mid);
        }
    }

    private class AcceptMember extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("AcceptMember");
            wb.addProperty("mid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(AAGroupApproveMemberItemDetails.this,s, Toast.LENGTH_SHORT).show();
        }
    }

    private class RejectMember extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("RejectMember");
            wb.addProperty("mid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(AAGroupApproveMemberItemDetails.this,s, Toast.LENGTH_SHORT).show();
        }
    }

    private class GetApproveMemberItemDetails extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetApproveMemberItemDetails");
            wb.addProperty("memberid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                JSONObject jo=ja.getJSONObject(0);
                String member=jo.getString("member");
                String place=jo.getString("place");
                String district=jo.getString("district");
                String contact=jo.getString("contact");
                String email=jo.getString("email");
                String address=jo.getString("address");
                String photo=jo.getString("photo");
                String mu=jo.getString("mu");

                txtmember.setText(member);
                txtplace.setText(place);
                txtdistrict.setText(district);
                txtcontact.setText(contact);
                txtemail.setText(email);
                txtaddress.setText(address);
                String urlip= getApplicationContext().getResources().getString(R.string.ip);
                if(mu.equals("1"))
                Picasso.with(getApplicationContext()).load("http://"+urlip+"/MainProject/AAGroup/MemberPhoto/"+photo+"").fit().into(imgbtn);
                else
                    Picasso.with(getApplicationContext()).load("http://"+urlip+"/MainProject/User/Photo/"+photo+"").fit().into(imgbtn);


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
