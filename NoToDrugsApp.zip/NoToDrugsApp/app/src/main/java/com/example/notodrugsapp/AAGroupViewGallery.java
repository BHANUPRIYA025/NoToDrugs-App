package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AAGroupViewGallery extends AppCompatActivity {

    String groupid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aagroup_view_gallery);
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        groupid=sp.getString("groupid","");
        GetGallery getGallery=new GetGallery();
        getGallery.execute(groupid);
    }

    private class GetGallery extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetGallery");
            wb.addProperty("groupid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                AAGroupViewGalleryItems[] myListData=new AAGroupViewGalleryItems[ja.length()];
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    String galleryid=jo.getString("galleryid");
                    String imagevideo=jo.getString("imagevideo");
                    String caption=jo.getString("caption");
                    myListData[i]=new AAGroupViewGalleryItems(galleryid,imagevideo,caption);
                }

                RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycle_view_gallery);
                AAGroupViewGalleryAdapter adapter = new AAGroupViewGalleryAdapter(getApplicationContext(),myListData);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(AAGroupViewGallery.this));
                recyclerView.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    }
}
