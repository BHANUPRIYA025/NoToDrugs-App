package com.example.notodrugsapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AAGroupRejectedMemberAdapter extends RecyclerView.Adapter<AAGroupRejectedMemberAdapter.ViewHolder>{

    private AAGroupRejectedMemberItems[] listdata;

    public AAGroupRejectedMemberAdapter(AAGroupRejectedMemberItems[] listdata) {
        this.listdata = listdata;
    }

    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.activity_aagroup_rejected_member_items, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        final AAGroupRejectedMemberItems myListData = listdata[position];
        holder.member.setText(listdata[position].getMember());
        holder.place.setText(listdata[position].getPlace());
        holder.district.setText(listdata[position].getDistrict());
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(view.getContext(),AAGroupRejectedMemberItemDetails.class);
                intent.putExtra("memberid",listdata[position].getMemberid());
                view.getContext().startActivity(intent);
                //Toast.makeText(view.getContext(),"click on item: "+myListData.getMemberid(),Toast.LENGTH_LONG).show();
            }
        });

    }

    public int getItemCount() {
        return listdata.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView member,district,place;
        public RelativeLayout relativeLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            this.member= (TextView) itemView.findViewById(R.id.txtmember);
            this.place = (TextView) itemView.findViewById(R.id.txtplace);
            this.district= (TextView) itemView.findViewById(R.id.txtdistrict);
            relativeLayout = (RelativeLayout)itemView.findViewById(R.id.aagrouprejectedmemberrelativelayout);
        }

    }

}
