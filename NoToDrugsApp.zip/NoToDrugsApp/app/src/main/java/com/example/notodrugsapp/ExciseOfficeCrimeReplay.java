package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ExciseOfficeCrimeReplay extends AppCompatActivity implements View.OnClickListener {

    EditText txtreplay;
    Button btnsubmit;
    String crimeid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excise_office_crime_replay);

        Intent i=getIntent();
        crimeid=i.getStringExtra("crimeid");

        txtreplay=findViewById(R.id.txtreplay);
        btnsubmit=findViewById(R.id.btnsubmit);

        btnsubmit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
      String replay=txtreplay.getText().toString();
      CrimeReportReplay crimeReportReplay=new CrimeReportReplay();
      crimeReportReplay.execute(crimeid,replay);

    }

    private class CrimeReportReplay extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("CrimeReportReplay");
            wb.addProperty("crimeid",strings[0]);
            wb.addProperty("replay",strings[1]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(ExciseOfficeCrimeReplay.this,s, Toast.LENGTH_SHORT).show();
        }
    }
}
