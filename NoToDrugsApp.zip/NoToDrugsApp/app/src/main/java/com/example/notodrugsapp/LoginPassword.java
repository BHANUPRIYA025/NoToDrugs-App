package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.lang.reflect.Array;

public class LoginPassword extends AppCompatActivity implements View.OnClickListener {

    EditText txtpassword;
    Button btnlogin;
    String uname,password,user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_password);
        SharedPreferences sp=getSharedPreferences("login", MODE_PRIVATE);
        uname=sp.getString("uname","");
        user=sp.getString("user","");
        //Toast.makeText(getApplicationContext(),uname,Toast.LENGTH_LONG).show();
        txtpassword=findViewById(R.id.txtpassword);
        btnlogin=findViewById(R.id.btnlogin);
        btnlogin.setOnClickListener(this);
    }
    private class CheckPassword extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("CheckPassword");
            wb.addProperty("username",uname);
            wb.addProperty("password",strings[0]);
            wb.addProperty("user",user);
            wb.callWebService();
            return wb.getResponse();
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            //Toast.makeText(LoginPassword.this,s, Toast.LENGTH_SHORT).show();
            if(s.equals("0"))
            {
                Toast.makeText(LoginPassword.this,"Invalid Password", Toast.LENGTH_SHORT).show();
            }
            else
            {
                if(user.equals("1"))
                {
                    SharedPreferences sp=getSharedPreferences("login", MODE_PRIVATE);
                    SharedPreferences.Editor editor=sp.edit();
                    editor.putString("userid",s);
                    editor.commit();
                    Intent intent = new Intent(getApplicationContext(),UserHomePage.class);
                    startActivity(intent);
                }
                else if(user.equals("2"))
                {
                    SharedPreferences sp=getSharedPreferences("login", MODE_PRIVATE);
                    SharedPreferences.Editor editor=sp.edit();
                    editor.putString("groupid",s);
                    editor.commit();
                    Intent intent=new Intent(getApplicationContext(),AAGroupHomePage.class);
                    startActivity(intent);
                }
                else if(user.equals("3"))
                {
                    SharedPreferences sp=getSharedPreferences("login", MODE_PRIVATE);
                    SharedPreferences.Editor editor=sp.edit();
                    editor.putString("officeid",s);
                    editor.commit();
                    Intent intent=new Intent(getApplicationContext(),ExciseOfficeHomePage.class);
                    startActivity(intent);
                }
            }
            /*if(s.equals("1"))
            {
                Intent intent = new Intent(getApplicationContext(),UserHomePage.class);
                startActivity(intent);
            }
            else if(s.equals("2"))
            {
                Intent intent=new Intent(getApplicationContext(),AAGroupHomePage.class);
                startActivity(intent);
            }
            else if(s.equals("3"))
            {
                Intent intent=new Intent(getApplicationContext(),ExciseOfficeHomePage.class);
                startActivity(intent);
            }
            else
            {
                Toast.makeText(LoginPassword.this,"Invalid Password", Toast.LENGTH_SHORT).show();
            }*/
        }
    }

    @Override
    public void onClick(View v) {
        password=txtpassword.getText().toString();
        CheckPassword checkPassword=new CheckPassword();
        checkPassword.execute(password);
    }
}
