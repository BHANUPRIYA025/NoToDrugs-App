package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class UserReportedCrime extends AppCompatActivity {
    String userid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_reported_crime);
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        userid=sp.getString("userid","");
        GetReportedCrime getReportedCrime=new GetReportedCrime();
        getReportedCrime.execute(userid);
    }
    private class GetReportedCrime extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetReportedCrime");
            wb.addProperty("userid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                UserReportedCrimeItems[] myListData=new UserReportedCrimeItems[ja.length()];
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    String crimeid=jo.getString("crimeid");
                    String crimename=jo.getString("crimename");
                    String date=jo.getString("reportdate");
                    myListData[i]=new UserReportedCrimeItems(crimeid,crimename,date);
                }
                RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycle_user_reported_crime);
                UserReportedCrimeAdapter adapter = new UserReportedCrimeAdapter(myListData);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(UserReportedCrime.this));
                recyclerView.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            //Toast.makeText(UserReportedCrime.this,s, Toast.LENGTH_SHORT).show();

        }
    }
}
