package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class AAGroupAddEvent extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {

    EditText txtvenue,txtaddress,dtstartdate,dtenddate,tmstarttime,tmendtime;
    Spinner speventtype;
    Button btnsubmit;
    String gid,startdate,enddate,starttime,endtime,venue,address,eventtypeid;
    List<String> arrlistEventTypeName,arrlistEventTypeId;

    DatePickerDialog picker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aagroup_add_event);
        arrlistEventTypeId=new ArrayList<String>();
        arrlistEventTypeName=new ArrayList<String>();

        dtstartdate=findViewById(R.id.dtstartdate);
        dtenddate=findViewById(R.id.dtenddate);
        tmstarttime=findViewById(R.id.tmstarttime);
        tmendtime=findViewById(R.id.tmendtime);
        txtvenue=findViewById(R.id.txtvenue);
        txtaddress=findViewById(R.id.txtvenue);
        speventtype=findViewById(R.id.speventtype);
        btnsubmit=findViewById(R.id.btnsubmit);

        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        gid=sp.getString("groupid","");

        GetEventType getEventType=new GetEventType();
        getEventType.execute(gid);
        speventtype.setOnItemSelectedListener(this);
        btnsubmit.setOnClickListener(this);

        dtstartdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AAGroupAddEvent.this, "clicked", Toast.LENGTH_LONG).show();
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);
                // date picker dialog
                picker = new DatePickerDialog(AAGroupAddEvent.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                dtstartdate.setText( year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);
                            }
                        }, year, month, day);

                picker.show();
            }
        });

        dtenddate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AAGroupAddEvent.this, "clicked", Toast.LENGTH_LONG).show();
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);
                // date picker dialog
                picker = new DatePickerDialog(AAGroupAddEvent.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                dtenddate.setText( year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);
                            }
                        }, year, month, day);

                picker.show();
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String etid=arrlistEventTypeId.get(position);
        ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
        eventtypeid=etid;
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {
        if(v==btnsubmit)
        {
            startdate=dtstartdate.getText().toString();
            enddate=dtenddate.getText().toString();
            starttime=tmstarttime.getText().toString();
            endtime=tmendtime.getText().toString();
            venue=txtvenue.getText().toString();
            address=txtaddress.getText().toString();
            AddEvent addEvent=new AddEvent();
            addEvent.execute(gid);
        }

    }

    private class GetEventType extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetEventType");
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    String etid=jo.getString("eventtypeid");
                    String etname=jo.getString("eventtypename");
                    arrlistEventTypeId.add(etid);
                    arrlistEventTypeName.add(etname);
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, arrlistEventTypeName);
                speventtype.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class AddEvent extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("AddEvent");
            wb.addProperty("gid",strings[0]);
            wb.addProperty("startdate",startdate);
            wb.addProperty("enddate",enddate);
            wb.addProperty("starttime",starttime);
            wb.addProperty("endtime",endtime);
            wb.addProperty("eventtypeid",eventtypeid);
            wb.addProperty("venue",venue);
            wb.addProperty("address",address);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(AAGroupAddEvent.this,s, Toast.LENGTH_SHORT).show();
        }
    }
}
