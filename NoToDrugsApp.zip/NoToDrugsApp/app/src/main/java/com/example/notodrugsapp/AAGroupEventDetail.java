package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AAGroupEventDetail extends AppCompatActivity {

    String gid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aagroup_event_detail);
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        gid=sp.getString("groupid","");
        GetEventDetail getEventDetail=new GetEventDetail();
        getEventDetail.execute(gid);

    }

    private class GetEventDetail extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetEventDetail");
            wb.addProperty("gid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                AAGroupEventDetailItems[] myListData=new AAGroupEventDetailItems[ja.length()];
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    String eventid=jo.getString("eventid");
                    String eventtype=jo.getString("eventtype");
                    String startdate=jo.getString("startdate");
                    String enddate=jo.getString("enddate");
                    String venue=jo.getString("venue");
                    myListData[i]=new AAGroupEventDetailItems(eventid,eventtype,startdate,enddate,venue);
                }

                RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycle_event_detail);
                AAGroupEventDetailAdapter adapter = new AAGroupEventDetailAdapter(myListData);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(AAGroupEventDetail.this));
                recyclerView.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}
