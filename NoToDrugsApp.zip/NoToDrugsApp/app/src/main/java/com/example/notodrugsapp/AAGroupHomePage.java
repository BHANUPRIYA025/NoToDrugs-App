package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class AAGroupHomePage extends AppCompatActivity implements View.OnClickListener {
    ImageButton imgmyprofile,imgeditprofile,imgchangepassword,imgmemberdetail,imgapprovemember,imgacceptedmember,imgrejectedmember,imgeventdetail,imgaddevent,imgviewgallery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aagroup_home_page);
        imgmyprofile=findViewById(R.id.imgmyprofile);
        imgeditprofile=findViewById(R.id.imgeditprofile);
        imgchangepassword=findViewById(R.id.imgchangepassword);
        imgmemberdetail=findViewById(R.id.imgmemberdetail);
        imgapprovemember=findViewById(R.id.imgapprovemember);
        imgacceptedmember=findViewById(R.id.imgacceptedmember);
        imgrejectedmember=findViewById(R.id.imgrejectedmember);
        imgeventdetail=findViewById(R.id.imgeventdetail);
        imgaddevent=findViewById(R.id.imgaddevent);
        imgviewgallery=findViewById(R.id.imgviewgallery);

        imgmyprofile.setOnClickListener(this);
        imgeditprofile.setOnClickListener(this);
        imgchangepassword.setOnClickListener(this);
        imgmemberdetail.setOnClickListener(this);
        imgapprovemember.setOnClickListener(this);
        imgacceptedmember.setOnClickListener(this);
        imgrejectedmember.setOnClickListener(this);
        imgeventdetail.setOnClickListener(this);
        imgaddevent.setOnClickListener(this);
        imgviewgallery.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v==imgmyprofile)
        {
            Intent intent=new Intent(getApplicationContext(),AAGroupMyProfile.class);
            startActivity(intent);
        }
        if(v==imgeditprofile)
        {
            Intent intent=new Intent(getApplicationContext(),AAGroupEditProfile.class);
            startActivity(intent);
        }
        if(v==imgchangepassword)
        {
            Intent intent=new Intent(getApplicationContext(),AAGroupChangePassword.class);
            startActivity(intent);
        }
        if(v==imgmemberdetail)
        {
            Intent intent=new Intent(getApplicationContext(),AAGroupMemberDetails.class);
            startActivity(intent);
        }
        if(v==imgapprovemember)
        {
            Intent intent=new Intent(getApplicationContext(),AAGroupApproveMember.class);
            startActivity(intent);
        }
        if(v==imgacceptedmember)
        {
            Intent intent=new Intent(getApplicationContext(),AAGroupAcceptedMember.class);
            startActivity(intent);
        }
        if(v==imgrejectedmember)
        {
            Intent intent=new Intent(getApplicationContext(),AAGroupRejectedMember.class);
            startActivity(intent);
        }
        if(v==imgeventdetail)
        {
            Intent intent=new Intent(getApplicationContext(),AAGroupEventDetail.class);
            startActivity(intent);
        }
        if(v==imgaddevent)
        {
            Intent intent=new Intent(getApplicationContext(),AAGroupAddEvent.class);
            startActivity(intent);
        }
        if(v==imgviewgallery)
        {
            Intent intent=new Intent(getApplicationContext(),AAGroupViewGallery.class);
            startActivity(intent);
        }
    }
}
