package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AAGroupApproveMember extends AppCompatActivity {

    String gid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aagroup_approve_member);
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        gid=sp.getString("groupid","");
        GetApproveMember getApproveMember=new GetApproveMember();
        getApproveMember.execute(gid);

    }

    private class GetApproveMember extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetApproveMember");
            wb.addProperty("gid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONArray ja= null;
            try {
                ja = new JSONArray(s);
                AAGroupApproveMemberItems[] myListData=new AAGroupApproveMemberItems[ja.length()];
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    String memberid=jo.getString("memberid");
                    String member=jo.getString("member");
                    String place=jo.getString("place");
                    String district=jo.getString("district");
                    myListData[i]=new AAGroupApproveMemberItems(memberid,member,place,district);

                }
                //Toast.makeText(AAGroupApproveMember.this,gid, Toast.LENGTH_SHORT).show();
                RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycle_approve_member);
                AAGroupApproveMemberAdapter adapter = new AAGroupApproveMemberAdapter(myListData);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(AAGroupApproveMember.this));
                recyclerView.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
