package com.example.notodrugsapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class UserEventDetailsAdapter extends RecyclerView.Adapter<UserEventDetailsAdapter.ViewHolder> {

    private UserEventDetailsItems[] listdata;

    public UserEventDetailsAdapter(UserEventDetailsItems[] listdata) {
        this.listdata = listdata;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.activity_user_event_details_items, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        final UserEventDetailsItems myListData = listdata[position];
        holder.group.setText(listdata[position].getGroup());
        holder.eventtype.setText(listdata[position].getEventtype());
        holder.edate.setText(listdata[position].getStartdate()+" - "+listdata[position].getEnddate());
        holder.venue.setText(listdata[position].getVenue());
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(view.getContext(),UserEventItemDetails.class);
                intent.putExtra("eventid",listdata[position].getEventid());
                view.getContext().startActivity(intent);
                Toast.makeText(view.getContext(),"click on item: "+myListData.getGroup(),Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return listdata.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView group,eventtype,edate,venue;
        public RelativeLayout relativeLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            this.group = (TextView) itemView.findViewById(R.id.txtaagroup);
            this.eventtype = (TextView) itemView.findViewById(R.id.txteventtype);
            this.edate = (TextView) itemView.findViewById(R.id.txtdate);
            this.venue = (TextView) itemView.findViewById(R.id.txtvenue);

            relativeLayout = (RelativeLayout)itemView.findViewById(R.id.usereventrelativelayout);
        }

    }
}
