package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class ExciseOfficeHomePage extends AppCompatActivity implements View.OnClickListener {
    ImageButton imgmyprofile,imgeditprofile,imgchangepassword,imgcrimereports;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excise_office_home_page);
        imgmyprofile=findViewById(R.id.imgmyprofile);
        imgeditprofile=findViewById(R.id.imgeditprofile);
        imgchangepassword=findViewById(R.id.imgchangepassword);
        imgcrimereports=findViewById(R.id.imgcrimereports);

        imgmyprofile.setOnClickListener(this);
        imgeditprofile.setOnClickListener(this);
        imgchangepassword.setOnClickListener(this);
        imgcrimereports.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
     if(v==imgmyprofile)
     {
         Intent intent=new Intent(getApplicationContext(),ExciseOfficeMyProfile.class);
         startActivity(intent);
     }
     if(v==imgeditprofile)
     {
         Intent intent=new Intent(getApplicationContext(),ExciseOfficeEditProfile.class);
         startActivity(intent);
     }
     if(v==imgchangepassword)
     {
         Intent intent=new Intent(getApplicationContext(),ExciseOfficeChangePassword.class);
         startActivity(intent);
     }
     if(v==imgcrimereports)
     {
         Intent intent=new Intent(getApplicationContext(),ExciseOfficeCrimeReports.class);
         startActivity(intent);
     }
    }
}
