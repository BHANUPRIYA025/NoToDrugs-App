package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class UserEventItemDetails extends AppCompatActivity {

    TextView txtaagroup,txteventtype,txtstartdate,txtenddate,txtstarttime,txtendtime,txtvenue,txtaddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_event_item_details);

        Intent i=getIntent();
        String eventid=i.getStringExtra("eventid");
        //Toast.makeText(this,eventid, Toast.LENGTH_SHORT).show();

        txtaagroup=findViewById(R.id.txtaagroup);
        txteventtype=findViewById(R.id.txteventtype);
        txtstartdate=findViewById(R.id.txtstartdate);
        txtenddate=findViewById(R.id.txtenddate);
        txtstarttime=findViewById(R.id.txtstarttime);
        txtendtime=findViewById(R.id.txtendtime);
        txtvenue=findViewById(R.id.txtvenue);
        txtaddress=findViewById(R.id.txtaddress);

        GetEventItemDetails getEventItemDetails=new GetEventItemDetails();
        getEventItemDetails.execute(eventid);

    }

    private class GetEventItemDetails extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetEventItemDetails");
            wb.addProperty("eventid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                    JSONObject jo=ja.getJSONObject(0);
                    String aagroup=jo.getString("aagroup");
                    String eventtype=jo.getString("eventtype");
                    String startdate=jo.getString("startdate");
                    String enddate=jo.getString("enddate");
                    String starttime=jo.getString("starttime");
                    String endtime=jo.getString("endtime");
                    String venue=jo.getString("venue");
                    String address=jo.getString("address");

                    txtaagroup.setText(aagroup);
                    txteventtype.setText(eventtype);
                    txtstartdate.setText(startdate);
                    txtenddate.setText(enddate);
                    txtstarttime.setText(starttime);
                    txtendtime.setText(endtime);
                    txtvenue.setText(venue);
                    txtaddress.setText(address);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
