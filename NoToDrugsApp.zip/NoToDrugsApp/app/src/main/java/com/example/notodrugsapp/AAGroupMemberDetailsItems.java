package com.example.notodrugsapp;

public class AAGroupMemberDetailsItems {
    private String memberid;
    private String member;
    private String designation;
    private String place;
    public AAGroupMemberDetailsItems(String memberid,String member,String designation,String place)
    {
        this.memberid=memberid;
        this.member=member;
        this.designation=designation;
        this.place=place;
    }



    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getMemberid() {
        return memberid;
    }

    public void setMemberid(String memberid) {
        this.memberid = memberid;
    }

    public String getMember() {
        return member;
    }

    public void setMember(String member) {
        this.member = member;
    }
}
