package com.example.notodrugsapp;

public class AAGroupRejectedMemberItems {

    private String memberid;
    private String member;
    private String place;
    private String district;

    public AAGroupRejectedMemberItems(String memberid, String member, String place, String district) {
        this.memberid = memberid;
        this.member = member;
        this.place = place;
        this.district = district;
    }

    public String getMemberid() {
        return memberid;
    }

    public void setMemberid(String memberid) {
        this.memberid = memberid;
    }

    public String getMember() {
        return member;
    }

    public void setMember(String member) {
        this.member = member;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }
}
