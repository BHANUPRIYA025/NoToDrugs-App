package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class UserSearchAAGroupItemDetails extends AppCompatActivity implements View.OnClickListener {

    TextView txtgroup,txtcontact,txtemail,txtplace,txtdistrict,txtaddress;
    Button btnjoin;
    ImageButton imgbtn;
    String groupid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_search_aagroup_item_details);

        Intent i=getIntent();
        groupid=i.getStringExtra("groupid");

        txtgroup=findViewById(R.id.txtgroup);
        txtcontact=findViewById(R.id.txtcontact);
        txtemail=findViewById(R.id.txtemail);
        txtplace=findViewById(R.id.txtplace);
        txtdistrict=findViewById(R.id.txtdistrict);
        txtaddress=findViewById(R.id.txtaddress);
        imgbtn=findViewById(R.id.pro_img);
        btnjoin=findViewById(R.id.btnjoin);

        GetSearchAAGroupItemDetails getSearchAAGroupItemDetails=new GetSearchAAGroupItemDetails();
        getSearchAAGroupItemDetails.execute(groupid);
        btnjoin.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        Intent intent=new Intent(v.getContext(),UserJoinAAGroup.class);
        String gid=groupid;
        intent.putExtra("groupid",gid);
        startActivity(intent);
    }

    private class GetSearchAAGroupItemDetails extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetSearchAAGroupItemDetails");
            wb.addProperty("groupid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                JSONObject jo=ja.getJSONObject(0);
                String group=jo.getString("group");
                String contact=jo.getString("contact");
                String email=jo.getString("email");
                String place=jo.getString("place");
                String district=jo.getString("district");
                String address=jo.getString("address");
                String photo=jo.getString("photo");

                txtgroup.setText(group);
                txtcontact.setText(contact);
                txtemail.setText(email);
                txtplace.setText(place);
                txtdistrict.setText(district);
                txtaddress.setText(address);
                String urlip= getApplicationContext().getResources().getString(R.string.ip);
                Picasso.with(getApplicationContext()).load("http://"+urlip+"/MainProject/AAGroup/Photo/"+photo+"").fit().into(imgbtn);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
