package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserSearchAAGroup extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner spdistrict;
    ListView lvaagroup;
    List<String> arrlistDistrictName,arrlistDistrictId,arrlistAAGroupName,arrlistAAGroupId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_search_aagroup);
        arrlistDistrictName=new ArrayList<String>();
        arrlistDistrictId=new ArrayList<String>();


        spdistrict=findViewById(R.id.spdistrict1);
        lvaagroup=findViewById(R.id.lvaagroup);

        spdistrict.setOnItemSelectedListener(this);
        lvaagroup.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(getApplicationContext(),arrlistAAGroupId.get(position),Toast.LENGTH_LONG).show();
                //((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
                String groupid=arrlistAAGroupId.get(position);
                Intent intent=new Intent(getApplicationContext(),UserSearchAAGroupItemDetails.class);
                intent.putExtra("groupid",groupid);
                startActivity(intent);
            }
        });

        GetDistrict getDistrict=new GetDistrict();
        getDistrict.execute();


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        //((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
        String did=arrlistDistrictId.get(position);
        GetAAGroups getAAGroups=new GetAAGroups();
        ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
        arrlistAAGroupName=new ArrayList<String>();
        arrlistAAGroupId=new ArrayList<String>();

        getAAGroups.execute(did);


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private class GetDistrict extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb = new WebServiceCaller();
            wb.setSoapObject("GetDistrict");
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja = new JSONArray(s);

                for (int i = 0; i < ja.length(); i++) {
                    JSONObject jsonObject1 = ja.getJSONObject(i);
                    String dname = jsonObject1.getString("districtname");
                    String did = jsonObject1.getString("districtid");
                    arrlistDistrictId.add(did);
                    arrlistDistrictName.add(dname);
                }
                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item,arrlistDistrictName);
                //adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);

                spdistrict.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class GetAAGroups extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb = new WebServiceCaller();
            wb.setSoapObject("GetAAGroups");
            wb.addProperty("districtid",strings[0]);

            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja = new JSONArray(s);
               // Toast.makeText(getApplicationContext(),ja.toString(),Toast.LENGTH_LONG).show();
                for (int i = 0; i < ja.length(); i++) {
                    JSONObject jsonObject1 = ja.getJSONObject(i);
                    String gname = "JOIN:  "+jsonObject1.getString("groupname");
                    String gid = jsonObject1.getString("groupid");
                    arrlistAAGroupId.add(gid);
                    arrlistAAGroupName.add(gname);
                }
                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1, arrlistAAGroupName);
                //adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
                lvaagroup.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
