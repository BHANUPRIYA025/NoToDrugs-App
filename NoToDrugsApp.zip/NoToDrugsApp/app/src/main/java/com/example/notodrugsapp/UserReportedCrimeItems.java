package com.example.notodrugsapp;

public class UserReportedCrimeItems {
    private String crimename;
    private String crimeid;
    private String date;

    public UserReportedCrimeItems( String crimeid,String crimename, String date) {
        this.crimename = crimename;
        this.crimeid = crimeid;
        this.date = date;
    }

    public String getCrimename() {
        return crimename;
    }

    public void setCrimename(String crimename) {
        this.crimename = crimename;
    }

    public String getCrimeid() {
        return crimeid;
    }

    public void setCrimeid(String crimeid) {
        this.crimeid = crimeid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
