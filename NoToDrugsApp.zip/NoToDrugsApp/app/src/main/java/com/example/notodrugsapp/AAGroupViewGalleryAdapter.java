package com.example.notodrugsapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

public class AAGroupViewGalleryAdapter extends RecyclerView.Adapter<AAGroupViewGalleryAdapter.ViewHolder> {

    private AAGroupViewGalleryItems[] listdata;
    private Context context;

    public AAGroupViewGalleryAdapter(Context context,AAGroupViewGalleryItems[] listdata) {
        this.listdata = listdata;
        this.context = context;
    }

    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.activity_aagroup_view_gallery_items, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        final AAGroupViewGalleryItems myListData = listdata[position];
        String urlip= context.getResources().getString(R.string.ip);
        String path="http://"+urlip+"/MainProject/AAGroup/EventGallery/"+listdata[position].getImagevideo();
        holder.caption.setText(listdata[position].getCaption());
        Picasso.with(context).load(path).error(R.drawable.imagenotfound).into(holder.imgimagevideo);

        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(view.getContext(),UserJoinedAAGroupItemDetails.class);
                intent.putExtra("galleryid",listdata[position].getGalleryid());
                view.getContext().startActivity(intent);
                Toast.makeText(view.getContext(),"click on item: "+myListData.getGalleryid(),Toast.LENGTH_LONG).show();
            }
        });

    }

    public int getItemCount() {
        return listdata.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public ImageView imgimagevideo;
        public TextView caption;
        public RelativeLayout relativeLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            imgimagevideo=(ImageView)itemView.findViewById(R.id.imgimagevideo);
            caption=(TextView)itemView.findViewById(R.id.txtcaption);
            relativeLayout = (RelativeLayout)itemView.findViewById(R.id.aagroupviewgalleryrelativelayout);
        }

    }
}
