package com.example.notodrugsapp;

public class AAGroupViewGalleryItems {

    private String galleryid;
    private String imagevideo;
    private String caption;

    public AAGroupViewGalleryItems(String galleryid, String imagevideo,String caption) {
        this.galleryid = galleryid;
        this.imagevideo = imagevideo;
        this.caption=caption;
    }

    public String getGalleryid() {
        return galleryid;
    }

    public void setGalleryid(String galleryid) {
        this.galleryid = galleryid;
    }

    public String getImagevideo() {
        return imagevideo;
    }

    public void setImagevideo(String imagevideo) {
        this.imagevideo = imagevideo;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }
}
