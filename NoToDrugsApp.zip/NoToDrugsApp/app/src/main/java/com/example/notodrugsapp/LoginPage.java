package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginPage extends AppCompatActivity implements View.OnClickListener {

    EditText txtusername;
    TextView txtuser,txtaagroup;
    Button btnlogin;
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        txtusername=findViewById(R.id.txtusername);
        txtuser=findViewById(R.id.txtuser);
        txtaagroup=findViewById(R.id.txtaagroup);
        btnlogin=findViewById(R.id.btnlogin);
        btnlogin.setOnClickListener(this);
        txtuser.setOnClickListener(this);
        txtaagroup.setOnClickListener(this);
    }

    private class CheckUsername extends AsyncTask<String,String,String>
    {


        @Override
        protected String doInBackground(String... strings) {

            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("CheckUsername");
            wb.addProperty("username",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            //Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
            if(s.equals("1")){
                SharedPreferences sp=getSharedPreferences("login", MODE_PRIVATE);
                SharedPreferences.Editor editor=sp.edit();
                editor.putString("uname",username);
                editor.putString("user","1");
                editor.commit();
                Intent intent=new Intent(getApplicationContext(),LoginPassword.class);
                startActivity(intent);
            }
            else if(s.equals("2")){
                SharedPreferences sp=getSharedPreferences("login", MODE_PRIVATE);
                SharedPreferences.Editor editor=sp.edit();
                editor.putString("uname",username);
                editor.putString("user","2");
                editor.commit();
                Intent intent=new Intent(getApplicationContext(),LoginPassword.class);
                startActivity(intent);
            }
            else if(s.equals("3")){
                SharedPreferences sp=getSharedPreferences("login", MODE_PRIVATE);
                SharedPreferences.Editor editor=sp.edit();
                editor.putString("uname",username);
                editor.putString("user","3");
                editor.commit();
                Intent intent=new Intent(getApplicationContext(),LoginPassword.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(LoginPage.this, "User Name Invalied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onClick(View v) {
        if(v==btnlogin) {
            username = txtusername.getText().toString();
            CheckUsername checkUsername = new CheckUsername();
            checkUsername.execute(username);
        }
        else if(v==txtuser)
        {
           Intent intent=new Intent(getApplicationContext(),UserRegistration.class);
           startActivity(intent);
        }
        else if(v==txtaagroup)
        {
            Intent intent=new Intent(getApplicationContext(),AAGroupRegistration.class);
            startActivity(intent);
        }

    }
}
