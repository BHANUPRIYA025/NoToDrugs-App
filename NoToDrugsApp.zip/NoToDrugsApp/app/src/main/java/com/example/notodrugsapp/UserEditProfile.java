package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserEditProfile extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {
    EditText txtname,txtcontact,txtaddress,txtemail;
    Spinner spdistrict,spplace;
    Button btnsubmit;
    RadioButton rdbmale,rdbfemale;
    String username,name,contact,gender,email,address,photo,district,place="";
    List<String> arrlistDistrictName,arrlistDistrictId,arrlistPlaceId,arrlistPlaceName;
    ImageButton imgbt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_edit_profile);
        arrlistDistrictName=new ArrayList<String>();
        arrlistDistrictId=new ArrayList<String>();
        txtname=findViewById(R.id.txtname);
        txtcontact=findViewById(R.id.txtcontact);
        txtaddress=findViewById(R.id.txtaddress);
        txtemail=findViewById(R.id.txtemail);
        spdistrict=findViewById(R.id.spdistrict);
        spplace=findViewById(R.id.spplace);
        rdbmale=findViewById(R.id.rdbmale);
        rdbfemale=findViewById(R.id.rdbfemale);
        btnsubmit=findViewById(R.id.btnsubmit);

        imgbt=(ImageButton)findViewById(R.id.pro_img);


        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        username=sp.getString("uname","");
        GetDistrict getDistrict=new GetDistrict();
        getDistrict.execute();
        spdistrict.setOnItemSelectedListener(this);
        GetUser2 getUser=new GetUser2();
        getUser.execute(username);
        btnsubmit.setOnClickListener(this);

        spplace.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        if(v==btnsubmit)
        {
            name=txtname.getText().toString();
            contact=txtcontact.getText().toString();
            email=txtemail.getText().toString();
            address=txtaddress.getText().toString();
            if(rdbmale.isChecked())
            {
                gender="male";
            }
            else
            {
                gender="female";
            }
            district=arrlistDistrictId.get(spdistrict.getSelectedItemPosition());
            place=arrlistPlaceId.get(spplace.getSelectedItemPosition());
            UpdateUser updateUser=new UpdateUser();
            updateUser.execute(name,gender,contact,email,address,district,place,username);

        }
    }

    private class GetDistrict extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb = new WebServiceCaller();
            wb.setSoapObject("GetDistrict");
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja = new JSONArray(s);
                //Toast.makeText(getApplicationContext(),ja.toString(),Toast.LENGTH_LONG).show();
                for (int i = 0; i < ja.length(); i++) {
                    JSONObject jsonObject1 = ja.getJSONObject(i);
                    String dname = jsonObject1.getString("districtname");
                    String did = jsonObject1.getString("districtid");
                    arrlistDistrictId.add(did);
                    arrlistDistrictName.add(dname);
                }
                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, arrlistDistrictName);
                //adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
                spdistrict.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        String did=arrlistDistrictId.get(position);
        ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
        GetPlace getPlace=new GetPlace();
        getPlace.execute(did);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private class GetPlace extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetPlace");
            wb.addProperty("districtid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                arrlistPlaceName=new ArrayList<String>();
                arrlistPlaceId=new ArrayList<String>();
                //Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    String pid=jo.getString("placeid");
                    String pname=jo.getString("placename");
                    //Log.d("id",pid);
                    arrlistPlaceId.add(pid);
                    arrlistPlaceName.add(pname);

                }
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, arrlistPlaceName);
                spplace.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if(place.equals("")==false)
            {

                int placeindex=arrlistPlaceId.indexOf(place);
                spplace.setSelection(placeindex);
            }
        }
    }

    private class GetUser2 extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetUser2");
            wb.addProperty("username",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                JSONObject jo=ja.getJSONObject(0);
                name=jo.getString("name");
                contact=jo.getString("contact");
                email=jo.getString("email");
                address=jo.getString("address");
                district=jo.getString("district");
                place=jo.getString("place");
                gender=jo.getString("gender");
                photo=jo.getString("photo");
                String urlip= getApplicationContext().getResources().getString(R.string.ip);
                Picasso.with(getApplicationContext()).load("http://"+urlip+"/MainProject/User/Photo/"+photo+"").fit().into(imgbt);
                txtname.setText(name);
                txtcontact.setText(contact);
                txtemail.setText(email);
                txtaddress.setText(address);
                if(gender.equals("male"))
                {
                    rdbmale.setChecked(true);
                }
                else
                {
                    rdbfemale.setChecked(true);
                }
                //Toast.makeText(UserEditProfile.this,place, Toast.LENGTH_SHORT).show();
                int districtindex=arrlistDistrictId.indexOf(district);
                spdistrict.setSelection(districtindex);
                GetPlace getPlace=new GetPlace();
                getPlace.execute(district);

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }
    private class UpdateUser extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("UpdateUser");
            wb.addProperty("name",strings[0]);
            wb.addProperty("gender",strings[1]);
            wb.addProperty("contact",strings[2]);
            wb.addProperty("email",strings[3]);
            wb.addProperty("address",strings[4]);
            wb.addProperty("districtid",strings[5]);
            wb.addProperty("placeid",strings[6]);
            wb.addProperty("username",strings[7]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(UserEditProfile.this,s, Toast.LENGTH_SHORT).show();
        }
    }
}
