package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserEventDetails extends AppCompatActivity {
    String username,userid;
    //List<String> arrlistEvents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_event_details);
        //arrlistEvents=new ArrayList<String>();
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        username=sp.getString("uname","");
        userid=sp.getString("userid","");
        GetEventDetails getEventDetails=new GetEventDetails();
        getEventDetails.execute(userid);



    }
    private class GetEventDetails extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetEventDetails");
            wb.addProperty("userid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                UserEventDetailsItems[] myListData=new UserEventDetailsItems[ja.length()];

                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    String eventid=jo.getString("eventid");
                    String group=jo.getString("group");
                    String eventtype=jo.getString("eventtype");
                    String startdate=jo.getString("startdate");
                    String enddate=jo.getString("enddate");
                    String starttime=jo.getString("starttime");
                    String endtime=jo.getString("endtime");
                    String venue=jo.getString("venue");
                    String address=jo.getString("address");

                    myListData[i]=new UserEventDetailsItems(eventid,group,eventtype,startdate,enddate,venue);


                }

                RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycle_userevent_details);
                UserEventDetailsAdapter adapter = new UserEventDetailsAdapter(myListData);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(UserEventDetails.this));
                recyclerView.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            //Toast.makeText(UserEventDetails.this,userid, Toast.LENGTH_SHORT).show();
        }
    }
}
