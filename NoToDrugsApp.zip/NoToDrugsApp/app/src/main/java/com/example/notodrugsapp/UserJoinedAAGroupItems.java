package com.example.notodrugsapp;

public class UserJoinedAAGroupItems {
    private String groupid;
    private String groupname;
    private String district;
    private String place;
    public UserJoinedAAGroupItems(String groupid,String groupname,String district,String place)
    {
        this.groupid=groupid;
        this.groupname = groupname;
        this.district = district;
        this.place = place;
    }

    public String getGroupname() {
        return groupname;
    }

    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }
}

