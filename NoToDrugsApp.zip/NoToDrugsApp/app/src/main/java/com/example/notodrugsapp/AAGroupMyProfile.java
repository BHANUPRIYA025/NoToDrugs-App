package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AAGroupMyProfile extends AppCompatActivity {
    TextView txtname,txtcontact,txtemail,txtaddress,txtdistrict,txtplace;
    String username,name,contact,email,address,district,place,photo;
    ImageButton imgbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aagroup_my_profile);
        txtname=findViewById(R.id.txtname);
        txtcontact=findViewById(R.id.txtcontact);
        txtemail=findViewById(R.id.txtemail);
        txtaddress=findViewById(R.id.txtaddress);
        txtdistrict=findViewById(R.id.txtdistrict);
        txtplace=findViewById(R.id.txtplace);
        imgbtn=findViewById(R.id.pro_img);

        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        username=sp.getString("uname","");
        GetAAGroup getAAGroup=new GetAAGroup();
        getAAGroup.execute(username);


    }
    private class GetAAGroup extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetAAGroup");
            wb.addProperty("username",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                JSONObject jo=ja.getJSONObject(0);
                name=jo.getString("name");
                contact=jo.getString("contact");
                email=jo.getString("email");
                address=jo.getString("address");
                district=jo.getString("district");
                place=jo.getString("place");
                photo=jo.getString("photo");

                txtname.setText(name);
                txtcontact.setText(contact);
                txtemail.setText(email);
                txtaddress.setText(address);
                txtdistrict.setText(district);
                txtplace.setText(place);
                String urlip= getApplicationContext().getResources().getString(R.string.ip);
                Picasso.with(getApplicationContext()).load("http://"+urlip+"/MainProject/AAGroup/MemberPhoto/"+photo+"").fit().into(imgbtn);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
