package com.example.notodrugsapp;

public class AAGroupEventDetailItems {

    private String eventid;
    private String eventtype;
    private String startdate;
    private String enddate;
    private String venue;

    public AAGroupEventDetailItems(String eventid, String eventtype, String startdate, String enddate, String venue) {
        this.eventid = eventid;
        this.eventtype = eventtype;
        this.startdate = startdate;
        this.enddate = enddate;
        this.venue = venue;
    }

    public String getEventid() {
        return eventid;
    }

    public void setEventid(String eventid) {
        this.eventid = eventid;
    }

    public String getEventtype() {
        return eventtype;
    }

    public void setEventtype(String eventtype) {
        this.eventtype = eventtype;
    }

    public String getStartdate() {
        return startdate;
    }

    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }

    public String getEnddate() {
        return enddate;
    }

    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }
}
