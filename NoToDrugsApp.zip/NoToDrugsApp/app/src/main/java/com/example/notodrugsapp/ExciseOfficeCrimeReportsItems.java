package com.example.notodrugsapp;

public class ExciseOfficeCrimeReportsItems {
    private String crimeid;
    private String crimename;
    private String user;
    private String reportdate;
    public ExciseOfficeCrimeReportsItems(String crimeid, String crimename, String user, String reportdate)
    {
        this.crimeid=crimeid;
        this.crimename=crimename;
        this.user=user;
        this.reportdate=reportdate;
    }

    public String getCrimeid() {
        return crimeid;
    }

    public void setCrimeid(String crimeid) {
        this.crimeid = crimeid;
    }

    public String getCrimename() {
        return crimename;
    }

    public void setCrimename(String crimename) {
        this.crimename = crimename;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getReportdate() {
        return reportdate;
    }

    public void setReportdate(String reportdate) {
        this.reportdate = reportdate;
    }
}
