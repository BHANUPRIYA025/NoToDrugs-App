package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;

public class UserHomePage extends AppCompatActivity implements View.OnClickListener {

    ImageButton imgmyprofile,imgeditprofile,imgchangepassword,imgjoinedaagroup,imgeventdetails,imgviewreportedcrime,imgchangeprofilepicture,imgsearchaagroup,imgsearchexciseoffice,imgreportcrime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home_page);
        imgmyprofile=findViewById(R.id.imgmyprofile);
        imgeditprofile=findViewById(R.id.imgeditprofile);
        imgchangepassword=findViewById(R.id.imgchangepassword);
        imgjoinedaagroup=findViewById(R.id.imgjoinedaagroup);
        imgeventdetails=findViewById(R.id.imgeventdetails);
        imgviewreportedcrime=findViewById(R.id.imgviewreportedcrime);
        imgchangeprofilepicture=findViewById(R.id.imgchangeprofilepic);
        imgsearchaagroup=findViewById(R.id.imgsearchaagroup);
        imgsearchexciseoffice=findViewById(R.id.imgsearchexciseoffice);
        imgreportcrime=findViewById(R.id.imgreportcrime);

        imgmyprofile.setOnClickListener(this);
        imgeditprofile.setOnClickListener(this);
        imgchangepassword.setOnClickListener(this);
        imgjoinedaagroup.setOnClickListener(this);
        imgeventdetails.setOnClickListener(this);
        imgviewreportedcrime.setOnClickListener(this);
        imgchangeprofilepicture.setOnClickListener(this);
        imgsearchaagroup.setOnClickListener(this);
        imgsearchexciseoffice.setOnClickListener(this);
        imgreportcrime.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v==imgmyprofile)
        {
            Intent intent=new Intent(getApplicationContext(),UserMyProfile.class);
            startActivity(intent);
        }
        if(v==imgeditprofile)
        {
            Intent intent=new Intent(getApplicationContext(),UserEditProfile.class);
            startActivity(intent);
        }
        if(v==imgchangepassword)
        {
            Intent intent=new Intent(getApplicationContext(),UserChangePassword.class);
            startActivity(intent);
        }
        if(v==imgjoinedaagroup)
        {
            Intent intent=new Intent(getApplicationContext(),UserJoinedAAGroup.class);
            startActivity(intent);
        }
        if(v==imgeventdetails)
        {
            Intent intent=new Intent(getApplicationContext(),UserEventDetails.class);
            startActivity(intent);
        }
        if(v==imgviewreportedcrime)
        {
            Intent intent=new Intent(getApplicationContext(),UserReportedCrime.class);
            startActivity(intent);
        }
        if(v==imgsearchaagroup)
        {
            Intent intent=new Intent(getApplicationContext(),UserSearchAAGroup.class);
            startActivity(intent);
        }
        if(v==imgsearchexciseoffice)
        {
            Intent intent=new Intent(getApplicationContext(),UserSearchExciseOffice.class);
            startActivity(intent);
        }
        if(v==imgreportcrime)
        {
            Intent intent=new Intent(getApplicationContext(),UserReportCrime.class);
            startActivity(intent);
        }
        if(v==imgchangeprofilepicture)
        {
            Intent intent=new Intent(getApplicationContext(),UserChangeProfilePicture.class);
            startActivity(intent);
        }

    }

    private class GetUserID extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetUserID");
            wb.addProperty("username",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }
    }
}
