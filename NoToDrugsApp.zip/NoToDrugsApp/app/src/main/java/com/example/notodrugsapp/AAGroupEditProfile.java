package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AAGroupEditProfile extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {

    EditText txtname,txtcontact,txtemail,txtaddress;
    Button btnsubmit;
    Spinner spdistrict,spplace;
    List<String> arrlistDistrictName,arrlistDistrictId,arrlistPlaceId,arrlistPlaceName;
    String username,name,contact,email,address,district,place,photo;
    ImageButton imgbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aagroup_edit_profile);
        arrlistDistrictName=new ArrayList<String>();
        arrlistDistrictId=new ArrayList<String>();
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        username=sp.getString("uname","");
        txtname=findViewById(R.id.txtname);
        txtcontact=findViewById(R.id.txtcontact);
        txtemail=findViewById(R.id.txtemail);
        txtaddress=findViewById(R.id.txtaddress);
        spdistrict=findViewById(R.id.spdistrict);
        spplace=findViewById(R.id.spplace);
        btnsubmit=findViewById(R.id.btnsubmit);
        imgbtn=findViewById(R.id.pro_img);

        GetDistrict getDistrict=new GetDistrict();
        getDistrict.execute();
        spdistrict.setOnItemSelectedListener(this);
        GetAAGroup2 getAAGroup2=new GetAAGroup2();
        getAAGroup2.execute(username);
        btnsubmit.setOnClickListener(this);

        /*spplace.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });*/

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String did=arrlistDistrictId.get(position);
        ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
        GetPlace getPlace=new GetPlace();
        getPlace.execute(did);

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {
        if(v==btnsubmit)
        {
            name=txtname.getText().toString();
            contact=txtcontact.getText().toString();
            email=txtemail.getText().toString();
            address=txtaddress.getText().toString();
            district=arrlistDistrictId.get(spdistrict.getSelectedItemPosition());
            place=arrlistPlaceId.get(spplace.getSelectedItemPosition());
            UpdateAAGroup updateUser=new UpdateAAGroup();
            updateUser.execute(name,contact,email,address,district,place,username);

        }

    }

    private class GetPlace extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetPlace");
            wb.addProperty("districtid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                arrlistPlaceName=new ArrayList<String>();
                arrlistPlaceId=new ArrayList<String>();
                //Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    String pid=jo.getString("placeid");
                    String pname=jo.getString("placename");
                    //Log.d("id",pid);
                    arrlistPlaceId.add(pid);
                    arrlistPlaceName.add(pname);

                }
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, arrlistPlaceName);
                spplace.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if(place.equals("")==false)
            {

                int placeindex=arrlistPlaceId.indexOf(place);
                spplace.setSelection(placeindex);
            }
        }
    }

    private class GetDistrict extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetDistrict");
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                for (int i = 0; i < ja.length(); i++) {
                    JSONObject jsonObject1 = ja.getJSONObject(i);
                    String dname = jsonObject1.getString("districtname");
                    String did = jsonObject1.getString("districtid");
                    arrlistDistrictId.add(did);
                    arrlistDistrictName.add(dname);
                }
                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, arrlistDistrictName);
                //adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
                spdistrict.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class GetAAGroup2 extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetAAGroup2");
            wb.addProperty("username",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                JSONObject jo=ja.getJSONObject(0);
                name=jo.getString("name");
                contact=jo.getString("contact");
                email=jo.getString("email");
                address=jo.getString("address");
                district=jo.getString("district");
                place=jo.getString("place");
                photo=jo.getString("photo");

                txtname.setText(name);
                txtcontact.setText(contact);
                txtemail.setText(email);
                txtaddress.setText(address);
                String urlip= getApplicationContext().getResources().getString(R.string.ip);
                Picasso.with(getApplicationContext()).load("http://"+urlip+"/MainProject/AAGroup/MemberPhoto/"+photo+"").fit().into(imgbtn);
                //Toast.makeText(AAGroupEditProfile.this,place, Toast.LENGTH_SHORT).show();
                int districtindex=arrlistDistrictId.indexOf(district);
                spdistrict.setSelection(districtindex);
                GetPlace getPlace=new GetPlace();
                getPlace.execute(district);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class UpdateAAGroup extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("UpdateAAGroup");
            wb.addProperty("name",strings[0]);
            wb.addProperty("contact",strings[1]);
            wb.addProperty("email",strings[2]);
            wb.addProperty("address",strings[3]);
            wb.addProperty("districtid",strings[4]);
            wb.addProperty("placeid",strings[5]);
            wb.addProperty("username",strings[6]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(AAGroupEditProfile.this,s, Toast.LENGTH_SHORT).show();

        }
    }
}
