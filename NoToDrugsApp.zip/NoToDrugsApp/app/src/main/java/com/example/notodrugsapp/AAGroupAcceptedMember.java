package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AAGroupAcceptedMember extends AppCompatActivity {

    String gid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aagroup_accepted_member);
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        gid=sp.getString("groupid","");
        GetAcceptedMember getAcceptedMember=new GetAcceptedMember();
        getAcceptedMember.execute(gid);
    }

    private class GetAcceptedMember extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetAcceptedMember");
            wb.addProperty("gid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                AAGroupAcceptedMemberItems[] myListData=new AAGroupAcceptedMemberItems[ja.length()];
                for(int i=0;i<ja.length();i++)
                {
                    JSONObject jo=ja.getJSONObject(i);
                    String memberid=jo.getString("memberid");
                    String member=jo.getString("member");
                    String place=jo.getString("place");
                    String district=jo.getString("district");
                    myListData[i]=new AAGroupAcceptedMemberItems(memberid,member,place,district);
                }

                //Toast.makeText(AAGroupAcceptedMember.this,gid, Toast.LENGTH_SHORT).show();
                RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycle_accepted_member);
                AAGroupAcceptedMemberAdapter adapter = new AAGroupAcceptedMemberAdapter(myListData);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(AAGroupAcceptedMember.this));
                recyclerView.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
