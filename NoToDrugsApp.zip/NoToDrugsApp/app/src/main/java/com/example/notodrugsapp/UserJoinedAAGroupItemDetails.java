package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class UserJoinedAAGroupItemDetails extends AppCompatActivity {

    TextView txtgroupname,txtplace,txtdistrict,txtcontact,txtemail,txtaddress;
    ImageButton imgbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_joined_aagroup_item_details);

        Intent i=getIntent();
        String groupid=i.getStringExtra("groupid");
        //Toast.makeText(this,groupid, Toast.LENGTH_SHORT).show();

        txtgroupname=findViewById(R.id.txtgroupname);
        txtplace=findViewById(R.id.txtplace);
        txtdistrict=findViewById(R.id.txtdistrict);
        txtcontact=findViewById(R.id.txtcontact);
        txtemail=findViewById(R.id.txtemail);
        txtaddress=findViewById(R.id.txtaddress);
        imgbtn=findViewById(R.id.pro_img);

        GetJoinedAAGroupItemDetails getJoinedAAGroupItemDetails=new GetJoinedAAGroupItemDetails();
        getJoinedAAGroupItemDetails.execute(groupid);
    }

    private class GetJoinedAAGroupItemDetails extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetJoinedAAGroupItemDetails");
            wb.addProperty("groupid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                JSONObject jo=ja.getJSONObject(0);
                String groupname=jo.getString("groupname");
                String place=jo.getString("place");
                String district=jo.getString("district");
                String contact=jo.getString("contact");
                String email=jo.getString("email");
                String address=jo.getString("address");
                String photo=jo.getString("photo");

                txtgroupname.setText(groupname);
                txtplace.setText(place);
                txtdistrict.setText(district);
                txtcontact.setText(contact);
                txtemail.setText(email);
                txtaddress.setText(address);
                String urlip= getApplicationContext().getResources().getString(R.string.ip);
                Picasso.with(getApplicationContext()).load("http://"+urlip+"/MainProject/AAGroup/Photo/"+photo+"").fit().into(imgbtn);
                Toast.makeText(UserJoinedAAGroupItemDetails.this, photo, Toast.LENGTH_SHORT).show();

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
