package com.example.notodrugsapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AAGroupEventDetailAdapter extends RecyclerView.Adapter<AAGroupEventDetailAdapter.ViewHolder>{

    private AAGroupEventDetailItems[] listdata;

    public AAGroupEventDetailAdapter(AAGroupEventDetailItems[] listdata) {
        this.listdata = listdata;
    }

    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.activity_aagroup_event_detail_items, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        final AAGroupEventDetailItems myListData = listdata[position];
        holder.eventtype.setText(listdata[position].getEventtype());
        holder.date.setText(listdata[position].getStartdate()+" - "+listdata[position].getEnddate());
        holder.venue.setText(listdata[position].getVenue());
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(view.getContext(),UserEventItemDetails.class);
                intent.putExtra("eventid",listdata[position].getEventid());
                view.getContext().startActivity(intent);
                //Toast.makeText(view.getContext(),"click on item: "+myListData.getEventid(),Toast.LENGTH_LONG).show();
            }
        });

    }

    public int getItemCount() {
        return listdata.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView eventtype,date,venue;
        public RelativeLayout relativeLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            this.eventtype = (TextView) itemView.findViewById(R.id.txteventtype);
            this.date = (TextView) itemView.findViewById(R.id.txtdate);
            this.venue = (TextView) itemView.findViewById(R.id.txtvenue);

            relativeLayout = (RelativeLayout)itemView.findViewById(R.id.aagroupeventdetailrelativelayout);
        }

    }

}
