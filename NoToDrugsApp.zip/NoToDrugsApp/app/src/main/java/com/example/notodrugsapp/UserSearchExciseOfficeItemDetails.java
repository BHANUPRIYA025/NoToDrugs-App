package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class UserSearchExciseOfficeItemDetails extends AppCompatActivity {

    TextView txtoffice,txtcontact,txtemail,txtplace,txtdistrict,txtaddress;
    ImageButton imgbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_search_excise_office_item_details);

        Intent i=getIntent();
        String officeid=i.getStringExtra("officeid");

        txtoffice=findViewById(R.id.txtoffice);
        txtcontact=findViewById(R.id.txtcontact);
        txtemail=findViewById(R.id.txtemail);
        txtplace=findViewById(R.id.txtplace);
        txtdistrict=findViewById(R.id.txtdistrict);
        txtaddress=findViewById(R.id.txtaddress);
        imgbtn=findViewById(R.id.pro_img);

        GetSearchExciseOfficeItemDetails getSearchExciseOfficeItemDetails=new GetSearchExciseOfficeItemDetails();
        getSearchExciseOfficeItemDetails.execute(officeid);
    }

    private class GetSearchExciseOfficeItemDetails extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetSearchExciseOfficeItemDetails");
            wb.addProperty("officeid",strings[0]);
            wb.callWebService();
            return wb.getResponse();

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                JSONObject jo=ja.getJSONObject(0);
                String office=jo.getString("office");
                String contact=jo.getString("contact");
                String email=jo.getString("email");
                String place=jo.getString("place");
                String district=jo.getString("district");
                String address=jo.getString("address");
                String photo=jo.getString("photo");

                txtoffice.setText(office);
                txtcontact.setText(contact);
                txtemail.setText(email);
                txtplace.setText(place);
                txtdistrict.setText(district);
                txtaddress.setText(address);
                String urlip= getApplicationContext().getResources().getString(R.string.ip);
                Picasso.with(getApplicationContext()).load("http://"+urlip+"/MainProject/ExciseOffice/Photo/"+photo+"").fit().into(imgbtn);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
