package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UserJoinAAGroup extends AppCompatActivity implements View.OnClickListener {

    EditText txtprofession;
    Button btnsubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_join_aagroup);

        txtprofession=findViewById(R.id.txtprofession);
        btnsubmit=findViewById(R.id.btnsubmit);

        btnsubmit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        Intent i=getIntent();
        String gid=i.getStringExtra("groupid");
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        String uid=sp.getString("userid","");
        JoinAAGroup joinAAGroup=new JoinAAGroup();
        String profession=txtprofession.getText().toString();
        joinAAGroup.execute(gid,uid,profession);

    }

    private class JoinAAGroup extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("JoinAAGroup");
            wb.addProperty("gid",strings[0]);
            wb.addProperty("uid",strings[1]);
            wb.addProperty("profession",strings[2]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s.equals("0"))
            {
                Toast.makeText(UserJoinAAGroup.this, "You are already a member", Toast.LENGTH_SHORT).show();
            }
            else if(s.equals("1"))
            {
                Toast.makeText(UserJoinAAGroup.this, "Success", Toast.LENGTH_SHORT).show();
            }
            else if(s.equals("2"))
            {
                Toast.makeText(UserJoinAAGroup.this, "Failed", Toast.LENGTH_SHORT).show();
            }

        }
    }
}
