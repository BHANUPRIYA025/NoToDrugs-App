package com.example.notodrugsapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class UserReportedCrimeAdapter extends RecyclerView.Adapter<UserReportedCrimeAdapter.ViewHolder> {

    private UserReportedCrimeItems[] listdata;

    public UserReportedCrimeAdapter(UserReportedCrimeItems[] listdata) {
        this.listdata = listdata;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.activity_user_reported_crime_items, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        final UserReportedCrimeItems myListData = listdata[position];
        holder.crimename.setText(listdata[position].getCrimename());
        holder.date.setText(listdata[position].getDate());
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(view.getContext(),UserReportedCrimeItemDetails.class);
                intent.putExtra("crimeid",listdata[position].getCrimeid());
                view.getContext().startActivity(intent);
                Toast.makeText(view.getContext(),"click on item: "+myListData.getCrimename(),Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return listdata.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView crimename,date;
        public RelativeLayout relativeLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            this.crimename = (TextView) itemView.findViewById(R.id.txtcrimename);
            this.date = (TextView) itemView.findViewById(R.id.txtdate);
            relativeLayout = (RelativeLayout)itemView.findViewById(R.id.userreportedcrimerelativelayout);
        }

    }
}
