package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AAGroupChangePassword extends AppCompatActivity implements View.OnClickListener {

    EditText txtcurrentpassword,txtnewpassword,txtconfirmpassword;
    Button btnsubmit;
    String currentpassword,newpassword,confirmpassword,username,originalpassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aagroup_change_password);
        txtcurrentpassword=findViewById(R.id.txtcurrentpassword);
        txtnewpassword=findViewById(R.id.txtnewpassword);
        txtconfirmpassword=findViewById(R.id.txtconfirmpassword);
        btnsubmit=findViewById(R.id.btnsubmit);
        SharedPreferences sp=getSharedPreferences("login",MODE_PRIVATE);
        username=sp.getString("uname","");
        GetAAGroupPassword getAAGroupPassword=new GetAAGroupPassword();
        getAAGroupPassword.execute(username);
        btnsubmit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v==btnsubmit)
        {
            currentpassword=txtcurrentpassword.getText().toString();
            newpassword=txtnewpassword.getText().toString();
            confirmpassword=txtconfirmpassword.getText().toString();
            if(newpassword.equals(confirmpassword)!=true)
            {
                Toast.makeText(this, "New Password and confirm password not matching", Toast.LENGTH_SHORT).show();
            }
            else if(currentpassword.equals(originalpassword))
            {

                ChangeUserPassword changeUserPassword=new ChangeUserPassword();
                changeUserPassword.execute(newpassword,username);
            }
            else
            {
                Toast.makeText(this, "Current Password is wrong", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class GetAAGroupPassword extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetAAGroupPassword");
            wb.addProperty("username",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            originalpassword=s;
        }
    }

    private class ChangeUserPassword extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("ChangeAAGroupPassword");
            wb.addProperty("newpassword",strings[0]);
            wb.addProperty("username",strings[1]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(AAGroupChangePassword.this,s, Toast.LENGTH_SHORT).show();
            GetAAGroupPassword getAAGroupPassword=new GetAAGroupPassword();
            getAAGroupPassword.execute(username);

        }
    }
}
