package com.example.notodrugsapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class UserJoinedAAGroupAdapter extends RecyclerView.Adapter<UserJoinedAAGroupAdapter.ViewHolder> {

    private UserJoinedAAGroupItems[] listdata;

    public UserJoinedAAGroupAdapter(UserJoinedAAGroupItems[] listdata) {
        this.listdata = listdata;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.activity_user_joined_aagroup_items, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        final UserJoinedAAGroupItems myListData = listdata[position];
        holder.groupname.setText(listdata[position].getGroupname());
        holder.district.setText(listdata[position].getDistrict());
        holder.place.setText(listdata[position].getPlace());
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(view.getContext(),UserJoinedAAGroupItemDetails.class);
                intent.putExtra("groupid",listdata[position].getGroupid());
                view.getContext().startActivity(intent);
                Toast.makeText(view.getContext(),"click on item: "+myListData.getGroupid(),Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return listdata.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView groupname,district,place;
        public RelativeLayout relativeLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            this.groupname= (TextView) itemView.findViewById(R.id.txtaagroup);
            this.district = (TextView) itemView.findViewById(R.id.txtdistrict);
            this.place= (TextView) itemView.findViewById(R.id.txtplace);
            relativeLayout = (RelativeLayout)itemView.findViewById(R.id.userjoinedaagrouprelativelayout);
        }

    }
}
