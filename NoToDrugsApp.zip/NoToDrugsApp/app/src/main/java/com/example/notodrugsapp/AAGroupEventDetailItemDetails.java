package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AAGroupEventDetailItemDetails extends AppCompatActivity {

    TextView txteventtype,txtstartdate,txtenddate,txtstarttime,txtendtime,txtvenue,txtaddress;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aagroup_event_detail_item_details);

        Intent i=getIntent();
        String eventid=i.getStringExtra("eventid");

        txteventtype=findViewById(R.id.txteventtype);
        txtstartdate=findViewById(R.id.txtstartdate);
        txtenddate=findViewById(R.id.txtenddate);
        txtstarttime=findViewById(R.id.txtstarttime);
        txtendtime=findViewById(R.id.txtendtime);
        txtvenue=findViewById(R.id.txtvenue);
        txtaddress=findViewById(R.id.txtaddress);
    }

    private class GetEventDetailItemDetails extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetEventDetailItemDetails");
            wb.addProperty("eventid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                JSONObject jo=ja.getJSONObject(0);
                String eventtype=jo.getString("eventtype");
                String startdate=jo.getString("startdate");
                String enddate=jo.getString("enddate");
                String starttime=jo.getString("starttime");
                String endtime=jo.getString("endtime");
                String venue=jo.getString("venue");
                String address=jo.getString("address");

                txteventtype.setText(eventtype);
                txtstartdate.setText(startdate);
                txtenddate.setText(enddate);
                txtstarttime.setText(starttime);
                txtendtime.setText(endtime);
                txtvenue.setText(venue);
                txtaddress.setText(address);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

}
