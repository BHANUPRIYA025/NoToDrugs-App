package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ExciseOfficeCrimeReportsItemDetails extends AppCompatActivity implements View.OnClickListener {

    TextView txtsubject,txtcrimecategory,txtuser,txtdescription,txtreporteddate;
    Button btnreplay;
    ImageButton imgbtn;
    String crimeid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excise_office_crime_reports_item_details);

        Intent i=getIntent();
        crimeid=i.getStringExtra("crimeid");

        txtsubject=findViewById(R.id.txtsubject);
        txtcrimecategory=findViewById(R.id.txtcrimecategory);
        txtuser=findViewById(R.id.txtuser);
        txtdescription=findViewById(R.id.txtdescription);
        txtreporteddate=findViewById(R.id.txtreporteddate);
        imgbtn=findViewById(R.id.pro_img);

        btnreplay=findViewById(R.id.btnreplay);

        GetCrimeReportsItemDetails getCrimeReportsItemDetails=new GetCrimeReportsItemDetails();
        getCrimeReportsItemDetails.execute(crimeid);

        btnreplay.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v==btnreplay)
        {
            Intent intent=new Intent(getApplicationContext(),ExciseOfficeCrimeReplay.class);
            String cid=crimeid;
            intent.putExtra("crimeid",cid);
            startActivity(intent);
        }
    }

    private class GetCrimeReportsItemDetails extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb=new WebServiceCaller();
            wb.setSoapObject("GetCrimeReportsItemDetails");
            wb.addProperty("crimeid",strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja=new JSONArray(s);
                JSONObject jo=ja.getJSONObject(0);
                String subject=jo.getString("subject");
                String crimecategory=jo.getString("crimecategory");
                String user=jo.getString("user");
                String description=jo.getString("description");
                String reporteddate=jo.getString("reporteddate");
                String photo=jo.getString("photo");

                txtsubject.setText(subject);
                txtcrimecategory.setText(crimecategory);
                txtuser.setText(user);
                txtdescription.setText(description);
                txtreporteddate.setText(reporteddate);
                String urlip= getApplicationContext().getResources().getString(R.string.ip);
                Picasso.with(getApplicationContext()).load("http://"+urlip+"/MainProject/User/CrimeProof/"+photo+"").fit().into(imgbtn);

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}
