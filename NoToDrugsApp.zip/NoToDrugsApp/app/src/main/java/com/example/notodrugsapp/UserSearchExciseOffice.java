package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserSearchExciseOffice extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner spdistrict;
    ListView lvexciseoffice;
    List<String> arrlistDistrictName,arrlistDistrictId,arrlistExciseOfficeName,arrlistExciseOfficeId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_search_excise_office);
        arrlistDistrictName=new ArrayList<String>();
        arrlistDistrictId=new ArrayList<String>();


        spdistrict=findViewById(R.id.spdistrict);
        lvexciseoffice=findViewById(R.id.lvexciseoffice);

        spdistrict.setOnItemSelectedListener(this);
        GetDistrict getDistrict=new GetDistrict();
        getDistrict.execute();
        lvexciseoffice.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(getApplicationContext(),arrlistExciseOfficeId.get(position),Toast.LENGTH_LONG).show();
                String officeid=arrlistExciseOfficeId.get(position);
                Intent intent=new Intent(getApplicationContext(),UserSearchExciseOfficeItemDetails.class);
                intent.putExtra("officeid",officeid);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        String did=arrlistDistrictId.get(position);
        GetExciseOffices getExciseOffices=new GetExciseOffices();
        ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.white));
        arrlistExciseOfficeName=new ArrayList<String>();
        arrlistExciseOfficeId=new ArrayList<String>();
        getExciseOffices.execute(did);


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private class GetDistrict extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb = new WebServiceCaller();
            wb.setSoapObject("GetDistrict");
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja = new JSONArray(s);
                //Toast.makeText(getApplicationContext(),ja.toString(),Toast.LENGTH_LONG).show();
                for (int i = 0; i < ja.length(); i++) {
                    JSONObject jsonObject1 = ja.getJSONObject(i);
                    String dname = jsonObject1.getString("districtname");
                    String did = jsonObject1.getString("districtid");
                    arrlistDistrictId.add(did);
                    arrlistDistrictName.add(dname);
                }
                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item,arrlistDistrictName);
                //adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);

                spdistrict.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class GetExciseOffices extends AsyncTask<String,String,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb = new WebServiceCaller();
            wb.setSoapObject("GetExciseOffices");
            wb.addProperty("districtid",strings[0]);

            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja = new JSONArray(s);
                // Toast.makeText(getApplicationContext(),ja.toString(),Toast.LENGTH_LONG).show();
                for (int i = 0; i < ja.length(); i++) {
                    JSONObject jsonObject1 = ja.getJSONObject(i);
                    String gname = jsonObject1.getString("officename");
                    String gid = jsonObject1.getString("officeid");
                    arrlistExciseOfficeId.add(gid);
                    arrlistExciseOfficeName.add(gname);
                }
                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1, arrlistExciseOfficeName);
                //adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
                lvexciseoffice.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
