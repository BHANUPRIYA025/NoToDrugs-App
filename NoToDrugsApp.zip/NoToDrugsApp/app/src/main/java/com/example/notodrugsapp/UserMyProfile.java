package com.example.notodrugsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class UserMyProfile extends AppCompatActivity {

    TextView txtname, txtgender, txtcontact, txtemail, txtdistrict, txtplace, txtaddress;
    String username, name, gender, contact, email, district, place, address, photo;

    ImageButton imgbt=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_my_profile);
        SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
        username = sp.getString("uname", "");
        txtname = findViewById(R.id.txtname);
        txtgender = findViewById(R.id.txtgender);
        txtcontact = findViewById(R.id.txtcontact);
        txtemail = findViewById(R.id.txtemail);
        txtdistrict = findViewById(R.id.txtdistrict);
        txtplace = findViewById(R.id.txtplace);
        txtaddress = findViewById(R.id.txtaddress);

        imgbt=(ImageButton)findViewById(R.id.pro_img);



        GetUser getUser=new GetUser();
        getUser.execute(username);

    }

    private class GetUser extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... strings) {
            WebServiceCaller wb = new WebServiceCaller();
            wb.setSoapObject("GetUser");
            wb.addProperty("username", strings[0]);
            wb.callWebService();
            return wb.getResponse();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray ja = new JSONArray(s);
                    JSONObject jo = ja.getJSONObject(0);
                    name = jo.getString("name");
                    gender = jo.getString("gender");
                    contact = jo.getString("contact");
                    email = jo.getString("email");
                    address = jo.getString("address");
                    district = jo.getString("district");
                    place = jo.getString("place");
                    photo=jo.getString("photo");
                    txtname.setText(name);
                    txtgender.setText(gender);
                    txtcontact.setText(contact);
                    txtemail.setText(email);
                    txtaddress.setText(address);
                    txtdistrict.setText(district);
                    txtplace.setText(place);
                    String urlip= getApplicationContext().getResources().getString(R.string.ip);
               // Toast.makeText(getApplicationContext(),"http://"+urlip +"/MainProject/User/Photo/flphoto1873.jpg",Toast.LENGTH_LONG).show();
               // Picasso.with(getApplicationContext()).load("http://"+urlip+"/MainProject/User/Photo/flphoto1873.jpg").fit().into(imgbt);
                Picasso.with(getApplicationContext()).load("http://"+urlip+"/MainProject/User/Photo/"+photo+"").fit().into(imgbt);
            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    }

}