/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package WebServicePackage;

import Database.ConnectionClass;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author BIBIN
 */
@WebService(serviceName = "NewWebService")
public class NewWebService {

    ConnectionClass con=new ConnectionClass();
    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "CheckUsername")
    public String CheckUsername(@WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String yn="false";
        String select1="Select * from tbl_user where username='"+username+"'";
        ResultSet rs1=con.selectCommand(select1);
        try {
            while(rs1.next())
            {
                yn="1";
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        String select2="Select * from tbl_aagroup where username='"+username+"'";
        ResultSet rs2=con.selectCommand(select2);
        try {
            while(rs2.next())
            {
                yn="2";
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        String select3="Select * from tbl_exciseoffice where username='"+username+"'";
        ResultSet rs3=con.selectCommand(select3);
        try {
            while(rs3.next())
            {
                yn="3";
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "CheckPassword")
    public String CheckPassword(@WebParam(name = "username") String username, @WebParam(name = "password") String password,@WebParam(name = "user") String user) {
        //TODO write your implementation code here:
        String yn="0";
        if(user.equals("1"))
        {
            String select1="Select * from tbl_user where username='"+username+"' and password='"+password+"'";
            ResultSet rs1=con.selectCommand(select1);
            try {
                while(rs1.next())
                {
                  yn=rs1.getString("user_id");  
                }
            } catch (SQLException ex) {
                Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if(user.equals("2"))
        {
            String select2="Select * from tbl_aagroup where username='"+username+"' and password='"+password+"'";
            ResultSet rs2=con.selectCommand(select2);
            try {
                while(rs2.next())
                {
                    yn=rs2.getString("group_id");
                }
            } catch (SQLException ex) {
                Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if(user.equals("3"))
        {
            String select3="Select * from tbl_exciseoffice where username='"+username+"' and password='"+password+"'";
            ResultSet rs3=con.selectCommand(select3);
            try {
                while(rs3.next())
                {
                    yn=rs3.getString("office_id");
                }
            } catch (SQLException ex) {
                Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
            }  
        }
        System.out.println(yn);
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetDistrict")
    public String GetDistrict() {
        //TODO write your implementation code here:
        String select="Select * from tbl_district";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            JSONObject jo;
            jo=new JSONObject();
            jo.put("districtid","0");
            jo.put("districtname","--------select District--------");
            ja.put(jo);
            while(rs.next())
            {
               jo=new JSONObject();
                try {
                    jo.put("districtid",rs.getString("district_id"));
                    jo.put("districtname",rs.getString("district_name"));
                    ja.put(jo);
                } catch (JSONException ex) {
                    Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
                }  
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetPlace")
    public String GetPlace(@WebParam(name = "districtid") String districtid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_place where district_id='"+districtid+"'";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            JSONObject jo;
            jo=new JSONObject();
            jo.put("placeid","0");
            jo.put("placename","--------select Place--------");
            ja.put(jo);
            while(rs.next())
            {
              jo=new JSONObject();
                try {
                    jo.put("placeid",rs.getString("place_id"));
                    jo.put("placename",rs.getString("place_name"));
                    ja.put(jo);
                } catch (JSONException ex) {
                    Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        //return districtid;
        System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "CreateUser")
    public String CreateUser(@WebParam(name = "name") String name, @WebParam(name = "gender") String gender, @WebParam(name = "contact") String contact, @WebParam(name = "email") String email, @WebParam(name = "address") String address, @WebParam(name = "districtid") String districtid, @WebParam(name = "placeid") String placeid, @WebParam(name = "username") String username, @WebParam(name = "password") String password) {
        //TODO write your implementation code here:
        String yn="";
        String insert="Insert into tbl_user(name,gender,contact,email,address,district_id,place_id,username,password,status,start_date,photo) values('"+name+"','"+gender+"','"+contact+"','"+email+"','"+address+"','"+districtid+"','"+placeid+"','"+username+"','"+password+"',0,curdate(),'default')";
        Boolean b=con.executeCommand(insert);
        System.out.println(insert);
        if(b==true)
            yn="success";
        else
            yn="fail";
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "CreateAAGroup")
    public String CreateAAGroup(@WebParam(name = "name") String name, @WebParam(name = "contact") String contact, @WebParam(name = "email") String email, @WebParam(name = "address") String address, @WebParam(name = "username") String username, @WebParam(name = "password") String password, @WebParam(name = "districtid") String districtid, @WebParam(name = "placeid") String placeid) {
        //TODO write your implementation code here:
        String yn="";
        String insert="Insert into tbl_aagroup(group_name,contact,email,address,username,password,district_id,place_id,status,start_date) values('"+name+"','"+contact+"','"+email+"','"+address+"','"+username+"','"+password+"','"+districtid+"','"+placeid+"',0,curdate())";
        Boolean b=con.executeCommand(insert);
        if(b==true)
            yn="success";
        else
            yn="fail";
        //System.out.println(insert);
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetUser")
    public String GetUser(@WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String select="Select * from tbl_user where username='"+username+"'";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
               JSONObject jo=new JSONObject();
               jo.put("name",rs.getString("name"));
               jo.put("gender",rs.getString("gender"));
               jo.put("contact",rs.getString("contact"));
               jo.put("email",rs.getString("email"));
               jo.put("address",rs.getString("address"));
               jo.put("photo",rs.getString("photo"));
               String districtid=rs.getString("district_id");
               String placeid=rs.getString("place_id");
               String select2="Select * from tbl_district d,tbl_place p where d.district_id=p.district_id and place_id='"+placeid+"' and p.district_id='"+districtid+"'";
               ResultSet rs2=con.selectCommand(select2);
               while(rs2.next())
               {
                   jo.put("district",rs2.getString("district_name"));
                   jo.put("place",rs2.getString("place_name"));
               }
               ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetAAGroup")
    public String GetAAGroup(@WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String select="Select * from tbl_aagroup where username='"+username+"'";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        //System.out.println(select);
        try {
            while(rs.next())
            {
               JSONObject jo=new JSONObject();
               jo.put("name",rs.getString("group_name"));
               jo.put("contact",rs.getString("contact"));
               jo.put("email",rs.getString("email"));
               jo.put("address",rs.getString("address"));
               jo.put("photo",rs.getString("photo"));
               String districtid=rs.getString("district_id");
               String placeid=rs.getString("place_id");
               String select2="Select * from tbl_district d,tbl_place p where d.district_id=p.district_id and place_id='"+placeid+"' and p.district_id='"+districtid+"'";
               ResultSet rs2=con.selectCommand(select2);
               while(rs2.next())
               {
                   jo.put("district",rs2.getString("district_name"));
                   jo.put("place",rs2.getString("place_name"));
               }
               ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetExciseOffice")
    public String GetExciseOffice(@WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String select="Select * from tbl_exciseoffice where username='"+username+"'";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
               JSONObject jo=new JSONObject();
               jo.put("name",rs.getString("office_name"));
               jo.put("contact",rs.getString("contact"));
               jo.put("email",rs.getString("email"));
               jo.put("address",rs.getString("address"));
               jo.put("photo",rs.getString("photo"));
               String districtid=rs.getString("district_id");
               String placeid=rs.getString("place_id");
               String select2="Select * from tbl_district d,tbl_place p where d.district_id=p.district_id and place_id='"+placeid+"' and p.district_id='"+districtid+"'";
               ResultSet rs2=con.selectCommand(select2);
               while(rs2.next())
               {
                   jo.put("district",rs2.getString("district_name"));
                   jo.put("place",rs2.getString("place_name"));
               }
               ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetUser2")
    public String GetUser2(@WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String select="Select * from tbl_user where username='"+username+"'";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
               JSONObject jo=new JSONObject();
               jo.put("name",rs.getString("name"));
               jo.put("gender",rs.getString("gender"));
               jo.put("contact",rs.getString("contact"));
               jo.put("email",rs.getString("email"));
               jo.put("address",rs.getString("address"));
               jo.put("photo",rs.getString("photo"));
               jo.put("district",rs.getString("district_id"));
               jo.put("place",rs.getString("place_id"));
               ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "UpdateUser")
    public String UpdateUser(@WebParam(name = "name") String name, @WebParam(name = "gender") String gender, @WebParam(name = "contact") String contact, @WebParam(name = "email") String email, @WebParam(name = "address") String address, @WebParam(name = "districtid") String districtid, @WebParam(name = "placeid") String placeid, @WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String yn="";
        String update="Update tbl_user set name='"+name+"',gender='"+gender+"',contact='"+contact+"',email='"+email+"',address='"+address+"',district_id='"+districtid+"',place_id='"+placeid+"' where username='"+username+"'";
        Boolean b=con.executeCommand(update);
        if(b==true)
            yn="Update successful";
        else
            yn="Update failed";
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetAAGroup2")
    public String GetAAGroup2(@WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String select="Select * from tbl_aagroup where username='"+username+"'";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
               JSONObject jo=new JSONObject();
               jo.put("name",rs.getString("group_name"));
               jo.put("contact",rs.getString("contact"));
               jo.put("email",rs.getString("email"));
               jo.put("address",rs.getString("address"));
               jo.put("district",rs.getString("district_id"));
               jo.put("place",rs.getString("place_id"));
               jo.put("photo",rs.getString("photo"));
               ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetExciseOffice2")
    public String GetExciseOffice2(@WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String select="Select * from tbl_exciseoffice where username='"+username+"'";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
               JSONObject jo=new JSONObject();
               jo.put("name",rs.getString("office_name"));
               jo.put("contact",rs.getString("contact"));
               jo.put("email",rs.getString("email"));
               jo.put("address",rs.getString("address"));
               jo.put("district",rs.getString("district_id"));
               jo.put("place",rs.getString("place_id"));
               jo.put("photo",rs.getString("photo"));
               ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "UpdateAAGroup")
    public String UpdateAAGroup(@WebParam(name = "name") String name, @WebParam(name = "contact") String contact, @WebParam(name = "email") String email, @WebParam(name = "address") String address, @WebParam(name = "districtid") String districtid, @WebParam(name = "placeid") String placeid, @WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String yn="";
        String update="Update tbl_aagroup set group_name='"+name+"',contact='"+contact+"',email='"+email+"',address='"+address+"',district_id='"+districtid+"',place_id='"+placeid+"' where username='"+username+"'";
        Boolean b=con.executeCommand(update);
        if(b==true)
            yn="Update successful";
        else
            yn="Update failed";
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "UpdateExciseOffice")
    public String UpdateExciseOffice(@WebParam(name = "name") String name, @WebParam(name = "contact") String contact, @WebParam(name = "email") String email, @WebParam(name = "address") String address, @WebParam(name = "districtid") String districtid, @WebParam(name = "placeid") String placeid, @WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String yn="";
        String update="Update tbl_exciseoffice set office_name='"+name+"',contact='"+contact+"',email='"+email+"',address='"+address+"',district_id='"+districtid+"',place_id='"+placeid+"' where username='"+username+"'";
        Boolean b=con.executeCommand(update);
        if(b==true)
            yn="Update successful";
        else
            yn="Update failed";
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetUserPassword")
    public String GetUserPassword(@WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String password="";
        String select="Select password from tbl_user where username='"+username+"'";
        ResultSet rs=con.selectCommand(select);
        try {
            while(rs.next())
            {
                password=rs.getString("password");
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return password;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "ChangeUserPassword")
    public String ChangeUserPassword(@WebParam(name = "newpassword") String newpassword, @WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String yn="";
        String update="Update tbl_user set password='"+newpassword+"' where username='"+username+"'";
        Boolean b=con.executeCommand(update);
        if(b==true)
        {
            yn="Password updated succesfully";
        }
        else
        {
            yn="Password update failed";
        }
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetAAGroupPassword")
    public String GetAAGroupPassword(@WebParam(name = "username") String username) {
        //TODO write your implementation code here:
       String password="";
        String select="Select password from tbl_aagroup where username='"+username+"'";
        ResultSet rs=con.selectCommand(select);
        try {
            while(rs.next())
            {
                password=rs.getString("password");
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return password;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "ChangeAAGroupPassword")
    public String ChangeAAGroupPassword(@WebParam(name = "newpassword") String newpassword, @WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String yn="";
        String update="Update tbl_aagroup set password='"+newpassword+"' where username='"+username+"'";
        Boolean b=con.executeCommand(update);
        if(b==true)
        {
            yn="Password updated succesfully";
        }
        else
        {
            yn="Password update failed";
        }
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetExciseOfficePassword")
    public String GetExciseOfficePassword(@WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String password="";
        String select="Select password from tbl_exciseoffice where username='"+username+"'";
        ResultSet rs=con.selectCommand(select);
        try {
            while(rs.next())
            {
                password=rs.getString("password");
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return password;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "ChangeExciseOfficePassword")
    public String ChangeExciseOfficePassword(@WebParam(name = "newpassword") String newpassword, @WebParam(name = "username") String username) {
        //TODO write your implementation code here:
        String yn="";
        String update="Update tbl_exciseoffice set password='"+newpassword+"' where username='"+username+"'";
        Boolean b=con.executeCommand(update);
        if(b==true)
        {
            yn="Password updated succesfully";
        }
        else
        {
            yn="Password update failed";
        }
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetJoinedAAGroup")
    public String GetJoinedAAGroup(@WebParam(name = "userid") String userid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_aagroup a inner join tbl_member m on a.group_id=m.group_id inner join tbl_district d on a.district_id=d.district_id inner join tbl_place p on p.place_id=a.place_id where user_id='"+userid+"'";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("groupid",rs.getString("group_id"));
                jo.put("groupname",rs.getString("group_name"));
                jo.put("district",rs.getString("district_name"));
                jo.put("place",rs.getString("place_name"));
                jo.put("contact",rs.getString("contact"));
                jo.put("email",rs.getString("email"));
                jo.put("address",rs.getString("address"));
                ja.put(jo);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        //System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetEventDetails")
    public String GetEventDetails(@WebParam(name = "userid") String userid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_event e inner join tbl_eventtype et on e.eventtype_id=et.eventtype_id inner join tbl_member m on e.group_id=m.group_id inner join tbl_aagroup ag on e.group_id=ag.group_id where user_id='"+userid+"' order by e.start_date";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("eventid",rs.getString("event_id"));
                jo.put("group",rs.getString("group_name"));
                jo.put("eventtype",rs.getString("eventtype_name"));
                jo.put("startdate",rs.getString("start_date"));
                jo.put("enddate",rs.getString("end_date"));
                jo.put("starttime",rs.getString("start_time"));
                jo.put("endtime",rs.getString("end_time"));
                jo.put("venue",rs.getString("venue"));
                jo.put("address",rs.getString("address"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetReportedCrime")
    public String GetReportedCrime(@WebParam(name = "userid") String userid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_crimereplay r inner join tbl_crimedetail cd on r.crime_id=cd.crime_id inner join tbl_crimecategory cc on cd.crimecategory_id=cc.crimecategory_id inner join tbl_user u on cd.user_id=u.user_id where cd.status=0 and u.user_id='"+userid+"'";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("crimeid",rs.getString("crime_id"));
                jo.put("crimename",rs.getString("crime_name"));
                jo.put("reportdate",rs.getString("report_date"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(select);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetAAGroups")
    public String GetAAGroups(@WebParam(name = "districtid") String districtid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_aagroup where district_id="+districtid;
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
               JSONObject jo=new JSONObject();
               jo.put("groupid",rs.getString("group_id"));
               jo.put("groupname",rs.getString("group_name"));
               ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetExciseOffices")
    public String GetExciseOffices(@WebParam(name = "districtid") String districtid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_exciseoffice where district_id="+districtid;
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
               JSONObject jo=new JSONObject();
               jo.put("officeid",rs.getString("office_id"));
               jo.put("officename",rs.getString("office_name"));
               ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetCategory")
    public String GetCategory() {
        //TODO write your implementation code here:
        String select="Select * from tbl_crimecategory";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            JSONObject jo=new JSONObject();
            jo.put("categoryid","");
            jo.put("categoryname","---select crime category---");
            ja.put(jo);
            while(rs.next())
            {
                jo=new JSONObject();
                jo.put("categoryid",rs.getString("crimecategory_id"));
                jo.put("categoryname",rs.getString("crimecategory_name"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        //System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetExciseOffices2")
    public String GetExciseOffices2(@WebParam(name = "uid") String uid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_user where user_id="+uid;
        ResultSet rs=con.selectCommand(select);
        
        String did="";
        try {
            while(rs.next())
            {
                did=rs.getString("district_id");
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        String select2="Select * from tbl_exciseoffice where district_id="+did;
        ResultSet rs2=con.selectCommand(select2);
        System.out.println(select2);
        JSONArray ja=new JSONArray();
        try {
            JSONObject jo=new JSONObject();
            jo.put("officeid","");
            jo.put("officename","---select excise office---");
            ja.put(jo);
            while(rs2.next())
            {
                jo=new JSONObject();
                jo.put("officeid",rs2.getString("office_id"));
                jo.put("officename",rs2.getString("office_name"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetCrimeReports")
    public String GetCrimeReports(@WebParam(name = "oid") String oid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_crimedetail where office_id="+oid;
        ResultSet rs=con.selectCommand(select);
        //System.out.println(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
              String select1="Select * from tbl_user where user_id="+rs.getString("user_id");
              ResultSet rs2=con.selectCommand(select1);
              while(rs2.next())
              {
                  JSONObject jo=new JSONObject();
                  jo.put("crimeid",rs.getString("crime_id"));
                  jo.put("crimename",rs.getString("crime_name"));
                  jo.put("user",rs2.getString("name"));
                  jo.put("reportdate",rs.getString("report_date"));
                  ja.put(jo);
                  
              }
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetMemberDetails")
    public String GetMemberDetails(@WebParam(name = "gid") String gid) {
        //TODO write your implementation code here:
        String select = "Select * from tbl_member m inner join tbl_place p on p.place_id=m.place_id inner join tbl_designation de on m.designation_id=de.designation_id where member_status=0 and group_id="+gid;
        ResultSet rs = con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("memberid",rs.getString("member_id"));
                jo.put("member",rs.getString("member_name"));
                jo.put("designation",rs.getString("designation_name"));
                jo.put("place",rs.getString("place_name"));
                ja.put(jo);   
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
         String select2 ="Select * from tbl_member m inner join tbl_user u on m.user_id=u.user_id inner join tbl_designation d on m.designation_id=d.designation_id inner join tbl_place p on p.place_id=u.place_id where member_status=1 and group_id="+gid;
         ResultSet rs2 = con.selectCommand(select2);
         try {
            while(rs2.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("memberid",rs2.getString("member_id"));
                jo.put("member",rs2.getString("name"));
                jo.put("designation",rs2.getString("designation_name"));
                jo.put("place",rs2.getString("place_name"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }   
        System.out.println(select2);
        
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetApproveMember")
    public String GetApproveMember(@WebParam(name = "gid") String gid) {
        //TODO write your implementation code here:
        String select = "Select * from tbl_member m inner join tbl_district d on m.district_id=d.district_id inner join tbl_place p on p.place_id=m.place_id where member_status=0 and group_id="+gid;
        ResultSet rs = con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
               JSONObject jo=new JSONObject();
               jo.put("memberid",rs.getString("member_id"));
               jo.put("member",rs.getString("member_name"));
               jo.put("place",rs.getString("place_name"));
               jo.put("district",rs.getString("district_name"));
               ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        
         String select2 = "Select * from tbl_member m inner join tbl_user u on m.user_id=u.user_id inner join tbl_district d on u.district_id=d.district_id inner join tbl_place p on p.place_id=u.place_id where member_status=0 and group_id="+gid;
         ResultSet rs2 = con.selectCommand(select2);
        try {
            while(rs2.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("memberid",rs2.getString("member_id"));
                jo.put("member",rs2.getString("name"));
                jo.put("place",rs2.getString("place_name"));
                jo.put("district",rs2.getString("district_name"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetAcceptedMember")
    public String GetAcceptedMember(@WebParam(name = "gid") String gid) {
        //TODO write your implementation code here:
        String select = "Select * from tbl_member m inner join tbl_district d on m.district_id=d.district_id inner join tbl_place p on p.place_id=m.place_id where member_status=1 and group_id="+gid;
        ResultSet rs = con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("memberid",rs.getString("member_id"));
                jo.put("member",rs.getString("member_name"));
                jo.put("place",rs.getString("place_name"));
                jo.put("district",rs.getString("district_name"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
         String select2 = "Select * from tbl_member m inner join tbl_user u on m.user_id=u.user_id inner join tbl_district d on u.district_id=d.district_id inner join tbl_place p on p.place_id=u.place_id where member_status=1 and group_id="+gid;
         ResultSet rs2 = con.selectCommand(select2);
        try {
            while(rs2.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("memberid",rs2.getString("member_id"));
                jo.put("member",rs2.getString("name"));
                jo.put("place",rs2.getString("place_name"));
                jo.put("district",rs2.getString("district_name"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        //System.out.println(ja);
        return ja.toString();
    }   

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetRejectedMember")
    public String GetRejectedMember(@WebParam(name = "gid") String gid) {
        //TODO write your implementation code here:
        String select = "Select * from tbl_member m inner join tbl_district d on m.district_id=d.district_id inner join tbl_place p on p.place_id=m.place_id where member_status=2 and group_id="+gid;
        ResultSet rs = con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
               JSONObject jo=new JSONObject();
               jo.put("memberid",rs.getString("member_id"));
               jo.put("member",rs.getString("member_name"));
               jo.put("place",rs.getString("place_name"));
               jo.put("district",rs.getString("district_name"));
               ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String select2 = "Select * from tbl_member m inner join tbl_user u on m.user_id=u.user_id inner join tbl_district d on u.district_id=d.district_id inner join tbl_place p on p.place_id=u.place_id where member_status=2 and group_id="+gid;
        ResultSet rs2 = con.selectCommand(select2);
        try {
            while(rs2.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("memberid",rs2.getString("member_id"));
                jo.put("member",rs2.getString("name"));
                jo.put("place",rs2.getString("place_name"));
                jo.put("district",rs2.getString("district_name"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetEventDetail")
    public String GetEventDetail(@WebParam(name = "gid") String gid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_event e inner join tbl_eventtype et on e.eventtype_id=et.eventtype_id where group_id="+gid;
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("eventid",rs.getString("event_id"));
                jo.put("eventtype",rs.getString("eventtype_name"));
                jo.put("startdate",rs.getString("start_date"));
                jo.put("enddate",rs.getString("end_date"));
                jo.put("venue",rs.getString("venue"));
                ja.put(jo);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }


    /**
     * Web service operation
     */
    @WebMethod(operationName = "AddEvent")
    public String AddEvent(@WebParam(name = "gid") String gid, @WebParam(name = "startdate") String startdate, @WebParam(name = "enddate") String enddate, @WebParam(name = "starttime") String starttime, @WebParam(name = "endtime") String endtime, @WebParam(name = "eventtypeid") String eventtypeid, @WebParam(name = "venue") String venue, @WebParam(name = "address") String address) {
        //TODO write your implementation code here:
        String yn;
        String insert="Insert into tbl_event(start_date,end_date,start_time,end_time,venue,address,eventtype_id,group_id) values('"+startdate+"','"+enddate+"','"+starttime+"','"+endtime+"','"+venue+"','"+address+"','"+eventtypeid+"','"+gid+"')";
        Boolean b=con.executeCommand(insert);
        if(b==true)
            yn="success";
        else
            yn="fail";
        System.out.println(insert);
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetEventType")
    public String GetEventType() {
        //TODO write your implementation code here:
        String select="Select * from tbl_eventtype";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            JSONObject jo=new JSONObject();
            jo.put("eventtypeid","");
            jo.put("eventtypename","---select event type---");
            ja.put(jo);
            while(rs.next())
            {
                jo=new JSONObject();
                jo.put("eventtypeid",rs.getString("eventtype_id"));
                jo.put("eventtypename",rs.getString("eventtype_name"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        //System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetEventItemDetails")
    public String GetEventItemDetails(@WebParam(name = "eventid") String eventid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_event e inner join tbl_aagroup a on e.group_id=a.group_id inner join tbl_eventtype et on e.eventtype_id=et.eventtype_id where event_id="+eventid;
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("aagroup",rs.getString("group_name"));
                jo.put("eventtype",rs.getString("eventtype_name"));
                jo.put("startdate",rs.getString("start_date"));
                jo.put("enddate",rs.getString("end_date"));
                jo.put("starttime",rs.getString("start_time"));
                jo.put("endtime",rs.getString("end_time"));
                jo.put("venue",rs.getString("venue"));
                jo.put("address",rs.getString("address"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetJoinedAAGroupItemDetails")
    public String GetJoinedAAGroupItemDetails(@WebParam(name = "groupid") String groupid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_aagroup a inner join tbl_place p on a.place_id=p.place_id inner join tbl_district d on a.district_id=d.district_id where group_id="+groupid;
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("groupname",rs.getString("group_name"));
                jo.put("place",rs.getString("place_name"));
                jo.put("district",rs.getString("district_name"));
                jo.put("contact",rs.getString("contact"));
                jo.put("email",rs.getString("email"));
                jo.put("address",rs.getString("address"));
                jo.put("photo",rs.getString("photo"));
                ja.put(jo);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetReportedCrimeItemDetails")
    public String GetReportedCrimeItemDetails(@WebParam(name = "crimeid") String crimeid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_crimedetail cd inner join tbl_exciseoffice eo on cd.office_id=eo.office_id inner join tbl_crimecategory cc on cd.crimecategory_id=cc.crimecategory_id inner join tbl_crimereplay cr on cd.crime_id=cr.crime_id where cd.crime_id="+crimeid;
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("subject",rs.getString("crime_name"));
                jo.put("crimecategory",rs.getString("crimecategory_name"));
                jo.put("office",rs.getString("office_name"));
                jo.put("description",rs.getString("description"));
                jo.put("reporteddate",rs.getString("report_date"));
                jo.put("replay",rs.getString("replay"));
                jo.put("photo",rs.getString("proof"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(select);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetCrimeReportsItemDetails")
    public String GetCrimeReportsItemDetails(@WebParam(name = "crimeid") String crimeid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_crimedetail cd inner join tbl_crimecategory cc on cd.crimecategory_id=cc.crimecategory_id inner join tbl_user u on cd.user_id=u.user_id where crime_id="+crimeid;
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("subject",rs.getString("crime_name"));
                jo.put("crimecategory",rs.getString("crimecategory_name"));
                jo.put("user",rs.getString("name"));
                jo.put("description",rs.getString("description"));
                jo.put("reporteddate",rs.getString("report_date"));
                jo.put("photo",rs.getString("proof"));
                ja.put(jo);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetMemberDetailsItemDetails")
    public String GetMemberDetailsItemDetails(@WebParam(name = "memberid") String memberid) {
        //TODO write your implementation code here:
        String select = "Select * from tbl_member m inner join tbl_district d on m.district_id=d.district_id inner join tbl_place p on p.place_id=m.place_id inner join tbl_designation de on m.designation_id=de.designation_id where member_status=0 and member_id="+memberid;
        ResultSet rs = con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("member",rs.getString("member_name"));
                jo.put("designation",rs.getString("designation_name"));
                jo.put("place",rs.getString("place_name"));
                jo.put("district",rs.getString("district_name"));
                jo.put("contact",rs.getString("member_contact"));
                jo.put("email",rs.getString("member_email"));
                jo.put("address",rs.getString("member_address"));
                jo.put("photo",rs.getString("member_photo"));
                jo.put("mu","1");
                ja.put(jo);        
    
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String select2 = "Select * from tbl_member m inner join tbl_user u on m.user_id=u.user_id inner join tbl_district d on u.district_id=d.district_id inner join tbl_place p on p.place_id=u.place_id inner join tbl_designation de on de.designation_id=m.designation_id where member_status=0 and member_id="+memberid;
        ResultSet rs2 = con.selectCommand(select2);
        try {
            while(rs2.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("member",rs2.getString("name"));
                jo.put("designation",rs2.getString("designation_name"));
                jo.put("place",rs2.getString("place_name"));
                jo.put("district",rs2.getString("district_name"));
                jo.put("contact",rs2.getString("contact"));
                jo.put("email",rs2.getString("email"));
                jo.put("address",rs2.getString("address"));
                jo.put("photo",rs2.getString("photo"));
                jo.put("mu","2");
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetApproveMemberItemDetails")
    public String GetApproveMemberItemDetails(@WebParam(name = "memberid") String memberid) {
        //TODO write your implementation code here:
        String select = "Select * from tbl_member m inner join tbl_district d on m.district_id=d.district_id inner join tbl_place p on p.place_id=m.place_id where member_status=0 and member_id="+memberid;
        ResultSet rs = con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("member",rs.getString("member_name"));
                jo.put("place",rs.getString("place_name"));
                jo.put("district",rs.getString("district_name"));
                jo.put("contact",rs.getString("member_contact"));
                jo.put("email",rs.getString("member_email"));
                jo.put("address",rs.getString("member_address"));
                jo.put("photo",rs.getString("member_photo"));
                jo.put("mu","1");
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String select2 = "Select * from tbl_member m inner join tbl_user u on m.user_id=u.user_id inner join tbl_district d on u.district_id=d.district_id inner join tbl_place p on p.place_id=u.place_id where member_status=0 and member_id="+memberid;
        ResultSet rs2 = con.selectCommand(select2);
        try {
            while(rs2.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("member",rs2.getString("name"));
                jo.put("place",rs2.getString("place_name"));
                jo.put("district",rs2.getString("district_name"));
                jo.put("contact",rs2.getString("contact"));
                jo.put("email",rs2.getString("email"));
                jo.put("address",rs2.getString("address"));
                jo.put("photo",rs2.getString("photo"));
                jo.put("mu","2");
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetAcceptedMemberItemDetails")
    public String GetAcceptedMemberItemDetails(@WebParam(name = "memberid") String memberid) {
        //TODO write your implementation code here:
        String select = "Select * from tbl_member m inner join tbl_district d on m.district_id=d.district_id inner join tbl_place p on p.place_id=m.place_id where member_status=1 and member_id="+memberid;
        ResultSet rs= con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("member",rs.getString("member_name"));
                jo.put("place",rs.getString("place_name"));
                jo.put("district",rs.getString("district_name"));
                jo.put("contact",rs.getString("member_contact"));
                jo.put("email",rs.getString("member_email"));
                jo.put("address",rs.getString("member_address"));
                jo.put("photo",rs.getString("member_photo"));
                jo.put("mu","1");
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String select2 = "Select * from tbl_member m inner join tbl_user u on m.user_id=u.user_id inner join tbl_district d on u.district_id=d.district_id inner join tbl_place p on p.place_id=u.place_id where member_status=1 and member_id="+memberid;
        ResultSet rs2 = con.selectCommand(select2);
        try {
            while(rs2.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("member",rs2.getString("name"));
                jo.put("place",rs2.getString("place_name"));
                jo.put("district",rs2.getString("district_name"));
                jo.put("contact",rs2.getString("contact"));
                jo.put("email",rs2.getString("email"));
                jo.put("address",rs2.getString("address"));
                jo.put("photo",rs2.getString("photo"));
                jo.put("mu","2");
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(select);
        System.out.println(select2);
        System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetRejectedMemberItemDetails")
    public String GetRejectedMemberItemDetails(@WebParam(name = "memberid") String memberid) {
        //TODO write your implementation code here:
        String select = "Select * from tbl_member m inner join tbl_district d on m.district_id=d.district_id inner join tbl_place p on p.place_id=m.place_id where member_status=2 and member_id="+memberid;
        ResultSet rs= con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("member",rs.getString("member_name"));
                jo.put("place",rs.getString("place_name"));
                jo.put("district",rs.getString("district_name"));
                jo.put("contact",rs.getString("member_contact"));
                jo.put("email",rs.getString("member_email"));
                jo.put("address",rs.getString("member_address"));
                jo.put("photo",rs.getString("member_photo"));
                jo.put("mu","1");
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String select2 = "Select * from tbl_member m inner join tbl_user u on m.user_id=u.user_id inner join tbl_district d on u.district_id=d.district_id inner join tbl_place p on p.place_id=u.place_id where member_status=2 and member_id="+memberid;
        ResultSet rs2 = con.selectCommand(select2);
        try {
            while(rs2.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("member",rs2.getString("name"));
                jo.put("place",rs2.getString("place_name"));
                jo.put("district",rs2.getString("district_name"));
                jo.put("contact",rs2.getString("contact"));
                jo.put("email",rs2.getString("email"));
                jo.put("address",rs2.getString("address"));
                jo.put("photo",rs2.getString("photo"));
                jo.put("mu","2");
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(select);
        System.out.println(select2);
        System.out.println(ja);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetEventDetailItemDetails")
    public String GetEventDetailItemDetails(@WebParam(name = "eventid") String eventid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_event e inner join tbl_eventtype et on e.eventtype_id=et.eventtype_id where event_id="+eventid;
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("eventtype",rs.getString("eventtype_name"));
                jo.put("startdate",rs.getString("start_date"));
                jo.put("enddate",rs.getString("end_date"));
                jo.put("starttime",rs.getString("start_time"));
                jo.put("endtime",rs.getString("end_time"));
                jo.put("venue",rs.getString("venue"));
                jo.put("address",rs.getString("address"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetSearchAAGroupItemDetails")
    public String GetSearchAAGroupItemDetails(@WebParam(name = "groupid") String groupid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_aagroup aag inner join tbl_district d on aag.district_id=d.district_id inner join tbl_place p on aag.place_id=p.place_id where aag.group_id="+groupid;
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("group",rs.getString("group_name"));
                jo.put("contact",rs.getString("contact"));
                jo.put("email",rs.getString("email"));
                jo.put("place",rs.getString("place_name"));
                jo.put("district",rs.getString("district_name"));
                jo.put("address",rs.getString("address"));
                jo.put("photo",rs.getString("photo"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetSearchExciseOfficeItemDetails")
    public String GetSearchExciseOfficeItemDetails(@WebParam(name = "officeid") String officeid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_exciseoffice eo inner join tbl_district d on eo.district_id=d.district_id inner join tbl_place p on eo.place_id=p.place_id where eo.office_id="+officeid;
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("office",rs.getString("office_name"));
                jo.put("contact",rs.getString("contact"));
                jo.put("email",rs.getString("email"));
                jo.put("place",rs.getString("place_name"));
                jo.put("district",rs.getString("district_name"));
                jo.put("address",rs.getString("address"));
                jo.put("photo",rs.getString("photo"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "JoinAAGroup")
    public String JoinAAGroup(@WebParam(name = "gid") String gid, @WebParam(name = "uid") String uid, @WebParam(name = "profession") String profession) {
        //TODO write your implementation code here:
        String yn="";
        String select="Select * from tbl_member where user_id='"+uid+"' and group_id='"+gid+"'";
                ResultSet rs=con.selectCommand(select);
                
        try {
            if(rs.next())
            {
                yn="0";
                
            }
            else
            {
                String insert="Insert into tbl_member(user_id,group_id,designation_id,profession,member_status) values('"+uid+"','"+gid+"',0,'"+profession+"',0)";
                boolean b=con.executeCommand(insert);
                if(b=true)
                {
                    yn="1";
                }
                else
                {
                    yn="2";
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(yn);
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "AcceptMember")
    public String AcceptMember(@WebParam(name = "mid") String mid) {
        //TODO write your implementation code here:
        String yn="";
        String update="Update tbl_member set member_status=1,date_of_join=curdate() where member_id='"+mid+"'";
        boolean b=con.executeCommand(update);
        System.out.println(update);
        if(b==true)
            yn="Success";
        else
            yn="Failed";
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "RejectMember")
    public String RejectMember(@WebParam(name = "mid") String mid) {
        //TODO write your implementation code here:
        String yn="";
        String update="Update tbl_member set member_status=2,date_of_join=curdate() where member_id='"+mid+"'";
        boolean b=con.executeCommand(update);
        System.out.println(update);
        if(b==true)
            yn="Succes";
        else
            yn="Failed";
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "CrimeReportReplay")
    public String CrimeReportReplay(@WebParam(name = "crimeid") String crimeid, @WebParam(name = "replay") String replay) {
        //TODO write your implementation code here:
        String yn;
        String insert="Insert into tbl_crimereplay(crime_id,replay) values('"+crimeid+"','"+replay+"')";
        System.out.println(insert);
        boolean b=con.executeCommand(insert);
        if(b==true)
            yn="Success";
        else
            yn="Failed";
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "CrimeReport")
    public String CrimeReport(@WebParam(name = "subject") String subject, @WebParam(name = "description") String description, @WebParam(name = "categoryid") String categoryid, @WebParam(name = "exciseofficeid") String exciseofficeid, @WebParam(name = "userid") String userid, @WebParam(name = "filename") String filename) {
        //TODO write your implementation code here:
        String yn="";
        String insert="Insert into tbl_crimedetail(user_id,crime_name,crimecategory_id,description,office_id,status,report_date,proof) values('"+userid+"','"+subject+"','"+categoryid+"','"+description+"','"+exciseofficeid+"',0,curdate(),'"+filename+"')";
        boolean b=con.executeCommand(insert);
        if(b==true)
            yn="Succes";
        else
            yn="Failed";
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "ChangeProfilePicture")
    public String ChangeProfilePicture(@WebParam(name = "userid") String userid, @WebParam(name = "filename") String filename) {
        //TODO write your implementation code here:
        String yn="";
        String update="Update tbl_user set photo='"+filename+"' where user_id='"+userid+"'";
        boolean b=con.executeCommand(update);
        if(b==true)
            yn="Success";
        else
            yn="Failed";
        return yn;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetUserPicture")
    public String GetUserPicture(@WebParam(name = "userid") String userid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_user where user_id='"+userid+"'";
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
               JSONObject jo=new JSONObject();
               jo.put("photo",rs.getString("photo"));
               ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(select);
        return ja.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "GetGallery")
    public String GetGallery(@WebParam(name = "groupid") String groupid) {
        //TODO write your implementation code here:
        String select="Select * from tbl_eventgallery where aagroup_id="+groupid;
        ResultSet rs=con.selectCommand(select);
        JSONArray ja=new JSONArray();
        try {
            while(rs.next())
            {
                JSONObject jo=new JSONObject();
                jo.put("galleryid",rs.getString("gallery_id"));
                jo.put("imagevideo",rs.getString("imagevideo"));
                jo.put("caption",rs.getString("caption"));
                ja.put(jo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(NewWebService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(ja);
        return ja.toString();
    }

    

}
